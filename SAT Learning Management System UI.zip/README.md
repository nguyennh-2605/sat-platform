
  # SAT Learning Management System UI

  This is a code bundle for SAT Learning Management System UI. The original project is available at https://www.figma.com/design/LIW5XjhMIu75RT2SBPtccS/SAT-Learning-Management-System-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  