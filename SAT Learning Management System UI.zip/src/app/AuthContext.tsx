import React, { createContext, useContext, useState, ReactNode } from "react";

export type Role = "teacher" | "student" | null;

interface AuthContextType {
  role: Role;
  login: (email: string) => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [role, setRole] = useState<Role>(null);

  const login = (email: string) => {
    if (email.toLowerCase().includes("teacher")) {
      setRole("teacher");
    } else if (email.toLowerCase().includes("student")) {
      setRole("student");
    } else {
      // default fallback
      setRole("student");
    }
  };

  const logout = () => {
    setRole(null);
  };

  return (
    <AuthContext.Provider value={{ role, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
