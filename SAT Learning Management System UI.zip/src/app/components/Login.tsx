import { useState } from "react";
import { useAuth } from "../AuthContext";
import { Lock, Mail } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import loginBg from "../../imports/___SAT_Exam_2025___Test_Format__Fees__Best_Preparation_Tips___Top_Universities.jpg";
import antLogo from "../../imports/image.png";

export function Login() {
  const { login } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      login(email);
    }
  };

  return (
    <div className="flex h-screen w-full bg-background overflow-hidden">
      {/* Left side: Login Form */}
      <div className="w-full lg:w-[480px] shrink-0 flex flex-col justify-center px-12 py-8 bg-card shadow-2xl z-10 relative">
        <div className="flex items-center gap-3 mb-10">
          <ImageWithFallback
            src={antLogo}
            alt="ANT Academy Logo"
            className="w-12 h-12 object-contain"
          />
          <div>
            <h1 className="text-xl font-bold tracking-tight text-foreground">
              ANT ACADEMY
            </h1>
            <p className="text-xs text-muted-foreground italic font-serif">
              Aspiring and Top-notch
            </p>
          </div>
        </div>

        <div className="mb-8">
          <h2 className="text-2xl font-bold text-foreground tracking-tight mb-2">
            Welcome back
          </h2>
          <p className="text-sm text-muted-foreground">
            Please enter your details to sign in.
          </p>
        </div>

        <form
          onSubmit={handleSubmit}
          className="flex flex-col gap-5"
        >
          <div className="flex flex-col gap-1.5">
            <label className="text-sm font-semibold text-foreground">
              Email or Username
            </label>
            <div className="relative">
              <Mail
                size={18}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
              />
              <input
                type="text"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email"
                className="w-full h-11 pl-10 pr-4 rounded-lg border border-border bg-background text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-[#1B7A5A] focus:border-transparent transition-all"
                required
              />
            </div>
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-sm font-semibold text-foreground">
              Password
            </label>
            <div className="relative">
              <Lock
                size={18}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
              />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full h-11 pl-10 pr-4 rounded-lg border border-border bg-background text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-[#1B7A5A] focus:border-transparent transition-all"
                required
              />
            </div>
          </div>

          <div className="flex items-center justify-between mt-1">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                className="w-4 h-4 rounded border-border text-[#1B7A5A] focus:ring-[#1B7A5A] accent-[#1B7A5A]"
              />
              <span className="text-sm text-muted-foreground font-medium">
                Remember me
              </span>
            </label>
            <button
              type="button"
              className="text-sm font-bold text-[#1B7A5A] hover:underline"
            >
              Forgot password?
            </button>
          </div>

          <button
            type="submit"
            className="mt-4 w-full h-11 bg-[#1B7A5A] hover:bg-[#125840] text-white font-bold rounded-lg transition-colors shadow-sm"
          >
            Sign in
          </button>
        </form>

        <div className="mt-8 p-4 bg-muted/50 rounded-lg border border-border text-sm">
          <p className="font-semibold text-foreground mb-2">
            Demo Credentials:
          </p>
          <ul className="space-y-1 text-muted-foreground text-xs">
            <li>
              <span className="font-medium text-foreground">
                Teacher:
              </span>{" "}
              teacher@demo.com
            </li>
            <li>
              <span className="font-medium text-foreground">
                Student:
              </span>{" "}
              student@demo.com
            </li>
            <li className="italic mt-2 opacity-80">
              (Any password will work)
            </li>
          </ul>
        </div>
      </div>

      {/* Right side: Image Background */}
      <div className="hidden lg:block flex-1 relative bg-muted">
        <ImageWithFallback
          src={loginBg}
          alt="SAT Preparation Background"
          className="w-full h-full object-cover"
        />
        {/* Overlay gradient */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent pointer-events-none" />
        <div className="absolute bottom-12 left-12 right-12 pointer-events-none">
          <h2 className="text-3xl font-bold text-white mb-2 shadow-sm drop-shadow-lg">
            Master the SAT
          </h2>
          <p className="text-white/90 text-lg drop-shadow-md max-w-xl">
            Join thousands of students achieving their dream
            scores through our comprehensive learning platform.
          </p>
        </div>
      </div>
    </div>
  );
}