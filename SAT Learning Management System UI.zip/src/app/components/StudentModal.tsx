import React from "react";
import {
  CheckCircle2,
  XCircle,
  Clock,
  Check,
  X,
} from "lucide-react";

interface StudentModalProps {
  onClose: () => void;
}

export default function StudentModal({
  onClose,
}: StudentModalProps) {
  // Dữ liệu giả lập cho Modal
  const student = {
    name: "Eleanor Vance",
    avatar: "EV",
    testName: "Rhetoric & Argumentation - Unit 4",
    date: "Oct 12, 2023",
    score: "85%",
    correctCount: 17,
    totalCount: 20,
    timeSpent: "38m 15s",
    avgTime: "1m 54s / q",
  };

  const questions = [
    {
      id: 1,
      time: "45s",
      isCorrect: true,
      studentAnswer: "A",
      text: "The author misrepresents the opponent's argument to make it easier to attack.",
    },
    {
      id: 2,
      time: "12s",
      isFast: true,
      isCorrect: false,
      studentAnswer: "C",
      studentText: "Ad Hominem",
      correctAnswer: "B",
      correctText: "Logical Fallacy",
    },
    {
      id: 3,
      time: "3m 10s",
      isCorrect: true,
      studentAnswer: "D",
      text: "It synthesizes the preceding arguments into a call to action while reinforcing the opening premise.",
    },
    // Thêm các câu khác để test scroll nếu muốn
    {
      id: 4,
      time: "1m 15s",
      isCorrect: true,
      studentAnswer: "B",
      text: "Appealing to the audience's sense of logic and reason.",
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 animate-in fade-in duration-200">
      {/* Modal Container: Bo tròn vừa phải (rounded-lg), khống chế chiều cao max-h-[90vh] */}
      <div className="bg-white w-full max-w-3xl rounded-lg shadow-xl flex flex-col max-h-[90vh] overflow-hidden">
        {/* ── HEADER TĨNH ── */}
        <div className="bg-[#f6faf6] p-6 border-b border-slate-200 flex justify-between items-center">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-[#1B7A5A] text-white flex items-center justify-center text-lg font-bold">
              {student.avatar}
            </div>
            <div>
              <h2 className="text-2xl font-bold text-slate-800">
                {student.name}
              </h2>
              <p className="text-sm text-slate-600 mt-0.5">
                {student.testName}{" "}
                <span className="mx-1">•</span> Attempted:{" "}
                {student.date}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-6 text-right">
            <div>
              <div className="text-[10px] font-bold text-slate-500 tracking-wider uppercase">
                Final Score
              </div>
              <div className="text-2xl font-bold text-[#1B7A5A]">
                {student.score}
              </div>
              <div className="text-xs text-slate-500">
                {student.correctCount}/{student.totalCount}{" "}
                Correct
              </div>
            </div>
            <div className="w-px h-10 bg-slate-300"></div>
            <div>
              <div className="text-[10px] font-bold text-slate-500 tracking-wider uppercase">
                Time Spent
              </div>
              <div className="text-2xl font-bold text-slate-800">
                {student.timeSpent}
              </div>
              <div className="text-xs text-slate-500">
                Avg. {student.avgTime}
              </div>
            </div>
          </div>
        </div>

        {/* ── BODY CÓ THỂ SCROLL ── */}
        <div className="flex-1 overflow-y-auto p-6 bg-slate-50/50 [&::-webkit-scrollbar]:w-2 [&::-webkit-scrollbar-track]:bg-transparent [&::-webkit-scrollbar-thumb]:bg-slate-300 [&::-webkit-scrollbar-thumb]:rounded-full">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-bold text-slate-800">
              Question Breakdown
            </h3>
            <div className="flex items-center gap-3">
              <span className="flex items-center gap-1.5 px-3 py-1 bg-emerald-50 border border-emerald-200 text-emerald-700 text-sm font-semibold rounded-md">
                <Check size={16} /> 17 Correct
              </span>
              <span className="flex items-center gap-1.5 px-3 py-1 bg-rose-50 border border-rose-200 text-rose-700 text-sm font-semibold rounded-md">
                <X size={16} /> 3 Incorrect
              </span>
            </div>
          </div>

          <div className="flex flex-col gap-4">
            {questions.map((q) => (
              <div
                key={q.id}
                className={`p-5 bg-white border rounded-md shadow-sm ${
                  q.isCorrect
                    ? "border-slate-200 border-l-4 border-l-[#1B7A5A]"
                    : "border-rose-200 border-l-4 border-l-rose-600"
                }`}
              >
                {/* Header câu hỏi */}
                <div className="flex items-center justify-between mb-4">
                  <span
                    className={`font-bold ${q.isCorrect ? "text-slate-700" : "text-rose-700"}`}
                  >
                    Question {q.id}
                  </span>
                  <div className="flex items-center gap-3">
                    <span
                      className={`flex items-center gap-1 text-xs font-semibold px-2 py-1 rounded-md ${
                        q.isFast
                          ? "bg-amber-100 text-amber-700"
                          : "bg-slate-100 text-slate-600"
                      }`}
                    >
                      <Clock size={12} /> {q.time}
                    </span>
                    {q.isCorrect ? (
                      <CheckCircle2
                        size={20}
                        className="text-[#1B7A5A] fill-[#1B7A5A]/10"
                      />
                    ) : (
                      <XCircle
                        size={20}
                        className="text-rose-600 fill-rose-600/10"
                      />
                    )}
                  </div>
                </div>

                {/* Nội dung câu trả lời */}
                {q.isCorrect ? (
                  // Layout Câu Đúng
                  <div className="bg-[#f0fdf4] border border-emerald-200 rounded-md p-3 flex gap-3">
                    <span className="text-[#1B7A5A] font-bold shrink-0">
                      {q.studentAnswer}
                    </span>
                    <div>
                      <p className="text-slate-800 text-sm font-medium">
                        {q.text}
                      </p>
                      <p className="text-[#1B7A5A] text-xs mt-1 font-semibold">
                        Student Answer & Correct Answer
                      </p>
                    </div>
                  </div>
                ) : (
                  // Layout Câu Sai
                  <div className="flex flex-col gap-2">
                    {/* Đáp án học sinh chọn */}
                    <div className="bg-rose-50 border border-rose-200 rounded-md p-3 flex gap-3">
                      <span className="text-rose-600 font-bold shrink-0">
                        {q.studentAnswer}
                      </span>
                      <div>
                        <p className="text-slate-800 text-sm font-medium">
                          {q.studentText}
                        </p>
                        <p className="text-rose-600 text-xs mt-1 font-semibold">
                          Student Answer
                        </p>
                      </div>
                    </div>
                    {/* Đáp án đúng */}
                    <div className="bg-[#f0fdf4] border border-emerald-200 rounded-md p-3 flex gap-3">
                      <span className="text-[#1B7A5A] font-bold shrink-0">
                        {q.correctAnswer}
                      </span>
                      <div>
                        <p className="text-slate-800 text-sm font-medium">
                          {q.correctText}
                        </p>
                        <p className="text-[#1B7A5A] text-xs mt-1 font-semibold">
                          Correct Answer
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* ── FOOTER TĨNH ── */}
        <div className="p-4 bg-white border-t border-slate-200 flex justify-end gap-3">
          <button className="px-5 py-2 text-sm font-bold text-slate-700 bg-white border border-slate-300 rounded-md hover:bg-slate-50 transition-colors">
            Print Report
          </button>
          <button
            onClick={onClose}
            className="px-6 py-2 text-sm font-bold text-white bg-[#0F4D38] rounded-md hover:bg-[#0F4D38]/90 transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
}