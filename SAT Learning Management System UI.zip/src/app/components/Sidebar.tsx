import {
  BookOpen,
  Users,
  AlertCircle,
  BarChart2,
  ChevronRight,
  Settings,
  MessageSquare,
  LogOut,
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import antLogo from "../../imports/z7922303598937_b5053db1ee0ac9bdd09e6b9bd5516d3b-removebg-preview.png";
import { useAuth } from "../AuthContext";

export type Module = "testbank" | "classroom" | "errorlog" | "analytics";

interface SidebarProps {
  active: Module;
  onChange: (m: Module) => void;
}

const allNavItems: { id: Module; label: string; icon: React.ReactNode }[] = [
  { id: "testbank",  label: "Test Bank",  icon: <BookOpen size={18} /> },
  { id: "classroom", label: "Classroom",  icon: <Users size={18} /> },
  { id: "errorlog",  label: "Error Log",  icon: <AlertCircle size={18} /> },
  { id: "analytics", label: "Analytics",  icon: <BarChart2 size={18} /> },
];

export function Sidebar({ active, onChange }: SidebarProps) {
  const { role, logout } = useAuth();

  // Filter out Error Log for teachers
  const navItems = allNavItems.filter(item => {
    if (role === "teacher" && item.id === "errorlog") return false;
    return true;
  });

  return (
    <aside className="flex flex-col w-56 shrink-0 h-screen bg-sidebar text-sidebar-foreground border-r border-sidebar-border">

      {/* ── Logo / Wordmark ─────────────────────────────── */}
      <div className="flex items-center gap-3 px-5 py-5 border-b border-sidebar-border">
        {/* Logo Image */}
        <ImageWithFallback
          src={antLogo}
          alt="ANT Academy Logo"
          className="w-14 h-14 object-contain shrink-0"
        />

        <div className="min-w-0">
          <p className="text-white text-xs leading-tight" style={{ fontWeight: 600, letterSpacing: "0.04em" }}>
            ANT ACADEMY
          </p>
          <p
            className="text-sidebar-accent-foreground text-xs leading-tight mt-0.5"
            style={{
              fontFamily: "'Playfair Display', Georgia, serif",
              fontStyle: "italic",
              fontWeight: 400,
              fontSize: "10px",
            }}
          >
            Aspiring and Top-notch
          </p>
        </div>
      </div>

      {/* ── Nav label ───────────────────────────────────── */}
      <p className="px-5 pt-5 pb-1.5 text-xs text-sidebar-accent-foreground uppercase tracking-widest" style={{ fontWeight: 600, letterSpacing: "0.08em" }}>
        Modules
      </p>

      {/* ── Nav items ───────────────────────────────────── */}
      <nav className="flex flex-col gap-0.5 px-3 flex-1">
        {navItems.map((item) => {
          const isActive = active === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onChange(item.id)}
              className={`flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm w-full text-left transition-all duration-150 group ${
                isActive
                  ? "bg-sidebar-primary text-white"
                  : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-white"
              }`}
            >
              <span
                className={
                  isActive
                    ? "text-white"
                    : "text-sidebar-accent-foreground group-hover:text-white"
                }
              >
                {item.icon}
              </span>
              <span className="flex-1" style={{ fontWeight: isActive ? 500 : 400 }}>
                {item.label}
              </span>
              {/* Gold active dot */}
              {isActive && (
                <span
                  className="w-1.5 h-1.5 rounded-full shrink-0"
                  style={{ background: "#E8C040" }}
                />
              )}
            </button>
          );
        })}
      </nav>

      {/* ── Bottom Nav ──────────────────────────────────── */}
      <div className="px-3 pb-4">
        <button className="flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm w-full text-left transition-all duration-150 text-sidebar-foreground hover:bg-sidebar-accent hover:text-white group">
          <Settings size={18} className="text-sidebar-accent-foreground group-hover:text-white" />
          <span className="flex-1">Settings</span>
        </button>
        <button className="flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm w-full text-left transition-all duration-150 text-sidebar-foreground hover:bg-sidebar-accent hover:text-white group mt-0.5">
          <MessageSquare size={18} className="text-sidebar-accent-foreground group-hover:text-white" />
          <span className="flex-1">Feedback</span>
        </button>
        <div className="my-2 border-t border-sidebar-border/50"></div>
        <button 
          onClick={logout}
          className="flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm w-full text-left transition-all duration-150 text-sidebar-foreground hover:bg-sidebar-accent hover:text-white group mt-0.5"
        >
          <LogOut size={18} className="text-sidebar-accent-foreground group-hover:text-white" />
          <span className="flex-1">Log out</span>
        </button>
      </div>
    </aside>
  );
}
