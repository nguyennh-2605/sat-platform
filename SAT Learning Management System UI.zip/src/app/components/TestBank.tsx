import { useState, useRef, useEffect } from "react";
import {
  Search,
  Clock,
  BookOpen,
  ChevronRight,
  Lock,
  Play,
  RotateCcw,
  MoreHorizontal,
  ArrowLeft,
  Save,
  Trash2,
  Plus,
} from "lucide-react";
import { GlobalHeader } from "./GlobalHeader";
import { useAuth } from "../AuthContext";
import { ExamCreator } from "./ExamCreator";

type Subject = "All" | "RW" | "Math";
type TestType = "All" | "Test" | "Assignment";
type Difficulty = "Easy" | "Medium" | "Hard";

interface EditableQuestion {
  id: number;
  prompt: string;
  answer: string;
  explanation: string;
}

interface Test {
  id: number;
  title: string;
  subject: "RW" | "Math" | "Mixed";
  type: "Test" | "Assignment";
  difficulty: Difficulty;
  questions: number;
  duration: number;
  avgScore: number;
  attempts: number;
  starred: boolean;
  locked: boolean;
  tags: string[];
  progress?: number; // 0-100 if in progress
  lastAttempt?: string;
  editableQuestions: EditableQuestion[];
}

const buildQuestions = (subject: "RW" | "Math" | "Mixed", count: number): EditableQuestion[] =>
  Array.from({ length: count }, (_, index) => {
    const number = index + 1;
    const mathPrompt = `Question ${number}: Solve a linear equation and select the value that satisfies the SAT-style constraint.`;
    const rwPrompt = `Question ${number}: Read the short passage and choose the revision that most improves clarity and precision.`;
    return {
      id: number,
      prompt:
        subject === "Math"
          ? mathPrompt
          : subject === "RW"
            ? rwPrompt
            : number % 2 === 0
              ? mathPrompt
              : rwPrompt,
      answer: number % 2 === 0 ? "B" : "C",
      explanation:
        "Check the tested skill first, eliminate answers that change the meaning, then verify the remaining choice against the question stem.",
    };
  });

const tests: Test[] = [
  {
    id: 1,
    title: "SAT Full Practice Test #8",
    subject: "Mixed",
    type: "Test",
    difficulty: "Hard",
    questions: 98,
    duration: 180,
    avgScore: 1320,
    attempts: 2847,
    starred: true,
    locked: false,
    tags: ["Official", "2024"],
    lastAttempt: "2 days ago",
    progress: 100,
    editableQuestions: buildQuestions("Mixed", 6),
  },
  {
    id: 2,
    title: "Math — Algebra Focus",
    subject: "Math",
    type: "Assignment",
    difficulty: "Medium",
    questions: 22,
    duration: 35,
    avgScore: 680,
    attempts: 1203,
    starred: false,
    locked: false,
    tags: ["Algebra", "Linear Eq"],
    progress: 0,
    editableQuestions: buildQuestions("Math", 5),
  },
  {
    id: 3,
    title: "RW — Reading Comprehension Sprint",
    subject: "RW",
    type: "Test",
    difficulty: "Easy",
    questions: 15,
    duration: 25,
    avgScore: 710,
    attempts: 892,
    starred: true,
    locked: false,
    tags: ["Passages", "Inference"],
    lastAttempt: "1 week ago",
    progress: 60,
    editableQuestions: buildQuestions("RW", 4),
  },
  {
    id: 4,
    title: "RW — Writing & Language Grammar",
    subject: "RW",
    type: "Assignment",
    difficulty: "Medium",
    questions: 44,
    duration: 35,
    avgScore: 660,
    attempts: 754,
    starred: false,
    locked: false,
    tags: ["Grammar", "Punctuation"],
    progress: 0,
    editableQuestions: buildQuestions("RW", 5),
  },
  {
    id: 5,
    title: "Math — Advanced Quadratics",
    subject: "Math",
    type: "Assignment",
    difficulty: "Hard",
    questions: 18,
    duration: 30,
    avgScore: 640,
    attempts: 621,
    starred: false,
    locked: true,
    tags: ["Quadratics", "Functions"],
    progress: 0,
    editableQuestions: buildQuestions("Math", 4),
  },
  {
    id: 6,
    title: "SAT Full Practice Test #7",
    subject: "Mixed",
    type: "Test",
    difficulty: "Medium",
    questions: 98,
    duration: 180,
    avgScore: 1280,
    attempts: 3102,
    starred: false,
    locked: false,
    tags: ["Official", "2023"],
    lastAttempt: "3 weeks ago",
    progress: 100,
    editableQuestions: buildQuestions("Mixed", 6),
  },
  {
    id: 7,
    title: "RW — Paired Passages Deep Dive",
    subject: "RW",
    type: "Test",
    difficulty: "Hard",
    questions: 20,
    duration: 28,
    avgScore: 690,
    attempts: 445,
    starred: false,
    locked: true,
    tags: ["Paired", "Evidence"],
    progress: 0,
    editableQuestions: buildQuestions("RW", 4),
  },
  {
    id: 8,
    title: "RW — Rhetoric & Style",
    subject: "RW",
    type: "Assignment",
    difficulty: "Hard",
    questions: 44,
    duration: 35,
    avgScore: 620,
    attempts: 389,
    starred: false,
    locked: false,
    tags: ["Rhetoric", "Style"],
    progress: 0,
    editableQuestions: buildQuestions("RW", 5),
  },
  {
    id: 9,
    title: "Math — Data Analysis & Statistics",
    subject: "Math",
    type: "Test",
    difficulty: "Medium",
    questions: 16,
    duration: 20,
    avgScore: 720,
    attempts: 1567,
    starred: true,
    locked: false,
    tags: ["Statistics", "Probability"],
    progress: 0,
    editableQuestions: buildQuestions("Math", 4),
  },
];

export function TestBank() {
  const { role } = useAuth();
  const [editableTests, setEditableTests] = useState<Test[]>(tests);
  const [editingTestId, setEditingTestId] = useState<number | null>(null);
  const [isCreatingExam, setIsCreatingExam] = useState(false);
  const [search, setSearch] = useState("");
  const [subject, setSubject] = useState<Subject>("All");
  const [type, setType] = useState<TestType>("All");
  const [difficulties, setDifficulties] = useState<
    Set<Difficulty>
  >(new Set());

  const toggleDifficulty = (d: Difficulty) => {
    setDifficulties((prev) => {
      const next = new Set(prev);
      next.has(d) ? next.delete(d) : next.add(d);
      return next;
    });
  };

  const editingTest = editableTests.find((test) => test.id === editingTestId);

  const updateQuestion = (
    testId: number,
    questionId: number,
    field: keyof Omit<EditableQuestion, "id">,
    value: string,
  ) => {
    setEditableTests((prev) =>
      prev.map((test) =>
        test.id === testId
          ? {
              ...test,
              editableQuestions: test.editableQuestions.map((question) =>
                question.id === questionId
                  ? { ...question, [field]: value }
                  : question,
              ),
            }
          : test,
      ),
    );
  };

  const deleteQuestion = (testId: number, questionId: number) => {
    setEditableTests((prev) =>
      prev.map((test) =>
        test.id === testId
          ? {
              ...test,
              questions: Math.max(0, test.questions - 1),
              editableQuestions: test.editableQuestions.filter(
                (question) => question.id !== questionId,
              ),
            }
          : test,
      ),
    );
  };

  if (role === "teacher" && isCreatingExam) {
    return <ExamCreator onBack={() => setIsCreatingExam(false)} />;
  }

  if (role === "teacher" && editingTest) {
    return (
      <ExamCreator 
        onBack={() => setEditingTestId(null)} 
        initialData={{
          title: editingTest.title,
          subject: editingTest.subject === "Mixed" ? "RW" : editingTest.subject, // Map to RW/Math for simple UI mockup
          timeLimit: editingTest.duration.toString(),
          modules: "2",
          content: editingTest.editableQuestions.map(q => `${q.id}. ${q.prompt}\nA) Option A\nB) Option B\nC) Option C\nD) Option D\nAnswer: ${q.answer}\n`).join("\n\n")
        }}
      />
    );
  }

  const filtered = editableTests.filter((t) => {
    const matchSearch =
      t.title.toLowerCase().includes(search.toLowerCase()) ||
      t.tags.some((tag) =>
        tag.toLowerCase().includes(search.toLowerCase()),
      );
    const matchSubject =
      subject === "All" ||
      t.subject === subject ||
      (subject !== "All" && t.subject === "Mixed");
    const matchType = type === "All" || t.type === type;
    const matchDiff =
      difficulties.size === 0 || difficulties.has(t.difficulty);
    return (
      matchSearch && matchSubject && matchType && matchDiff
    );
  });

  return (
    <div className="flex flex-col h-full bg-background overflow-hidden">
      <GlobalHeader
        title="Test Bank"
        subtitle="Browse and attempt SAT practice tests"
      />

      {/* ── Grid & Filters ────────────────────────────────────────── */}
      <div className="flex-1 overflow-y-auto p-8 pt-6">
        <div className="max-w-[1200px] mx-auto">
          {/* Top Bar with Info and Filters */}
          <div className="flex flex-col gap-4 mb-8 bg-card border border-border p-4 rounded-xl">
            {/* LAYER 1: Search Bar & Sort By cùng 1 hàng */}
            <div className="flex items-center justify-between gap-4">
              {/* Search */}
              <div className="relative flex-1 max-w-md">
                <Search
                  size={14}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
                />
                <input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search tests..."
                  className="w-full pl-9 pr-3 py-1.5 rounded-lg border border-border bg-background text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-[#1B7A5A]/50 focus:border-[#1B7A5A]"
                />
              </div>

              {/* Sort By Dropdown */}
              <div className="flex items-center gap-4 shrink-0">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium text-foreground">
                    Sort by:
                  </span>
                  <select className="text-sm bg-background border border-border rounded-lg px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-[#1B7A5A]/50 text-foreground cursor-pointer">
                    <option>Newest</option>
                    <option>Oldest</option>
                  </select>
                </div>
                {role === "teacher" && (
                  <button 
                    onClick={() => setIsCreatingExam(true)}
                    className="flex items-center gap-2 px-4 py-1.5 bg-[#1B7A5A] text-white rounded-lg text-sm font-medium hover:bg-[#145f47] transition-colors"
                  >
                    <Plus size={16} /> Create Exam
                  </button>
                )}
              </div>
            </div>

            {/* LAYER 2: Phần filter chuyển xuống dưới */}
            <div className="flex flex-wrap items-center gap-6 border-t border-border pt-4 mt-1">
              {/* Subject */}
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-medium text-muted-foreground mr-1">
                  Subject:
                </span>
                {(["All", "RW", "Math"] as Subject[]).map(
                  (s) => (
                    <PillButton
                      key={s}
                      label={s}
                      active={subject === s}
                      onClick={() => setSubject(s)}
                    />
                  ),
                )}
              </div>

              {/* Type */}
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-medium text-muted-foreground mr-1">
                  Type:
                </span>
                {(
                  ["All", "Test", "Assignment"] as TestType[]
                ).map((t) => (
                  <PillButton
                    key={t}
                    label={t}
                    active={type === t}
                    onClick={() => setType(t)}
                  />
                ))}
              </div>

              {/* Difficulty */}
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-medium text-muted-foreground mr-1">
                  Difficulty:
                </span>
                {(
                  ["Easy", "Medium", "Hard"] as Difficulty[]
                ).map((d) => (
                  <PillButton
                    key={d}
                    label={d}
                    active={difficulties.has(d)}
                    onClick={() => toggleDifficulty(d)}
                  />
                ))}
              </div>
            </div>
          </div>

          {filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 text-muted-foreground">
              <Search size={32} className="mb-3 opacity-40" />
              <p className="text-sm">
                No tests match your filters.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {filtered.map((test) => (
                <TestCard
                  key={test.id}
                  test={test}
                  isTeacher={role === "teacher"}
                  onEdit={() => setEditingTestId(test.id)}
                  onDelete={() => {
                    setEditableTests(prev => prev.filter(t => t.id !== test.id));
                  }}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* ── Pill button ─────────────────────────────────────────── */
function PillButton({
  label,
  active,
  onClick,
}: {
  label: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="px-3 py-1 rounded-full text-xs border transition-all duration-150"
      style={
        active
          ? {
              background: "#1B7A5A",
              color: "#fff",
              borderColor: "#1B7A5A",
              fontWeight: 600,
            }
          : {
              background: "#fff",
              color: "#1B7A5A",
              borderColor: "#1B7A5A",
              fontWeight: 500,
            }
      }
    >
      {label}
    </button>
  );
}

/* ── Subject badge colors ────────────────────────────────── */
const subjectStyle = {
  RW: {
    background: "#E8F5EF",
    color: "#1B7A5A",
    border: "1px solid #c2ddd4",
  },
  Math: {
    background: "#FEF9E7",
    color: "#92640a",
    border: "1px solid #f0d070",
  },
  Mixed: {
    background: "#f3f4f6",
    color: "#4b5563",
    border: "1px solid #d1d5db",
  },
};

/* ── Test Card ───────────────────────────────────────────── */
function TestCard({
  test,
  isTeacher,
  onEdit,
  onDelete,
}: {
  test: Test;
  isTeacher: boolean;
  onEdit: () => void;
  onDelete: () => void;
}) {
  const ss = subjectStyle[test.subject];
  const isComplete = test.progress === 100;
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setMenuOpen(false);
      }
    }
    if (menuOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    }
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [menuOpen]);

  return (
    <div
      className={`bg-card border rounded-xl p-5 flex flex-col gap-3 hover:shadow-md transition-all duration-200 relative group ${
        test.locked ? "opacity-60" : "hover:border-[#1B7A5A]/40"
      } border-border`}
    >
      {test.locked && (
        <div className="absolute top-3 right-3 w-6 h-6 rounded-full bg-muted flex items-center justify-center">
          <Lock size={11} className="text-muted-foreground" />
        </div>
      )}

      {/* Top row */}
      <div className="flex items-start justify-between gap-2">
        <div className="flex flex-wrap gap-1.5">
          <span
            className="text-xs px-2 py-0.5 rounded-full"
            style={{ ...ss, fontSize: "11px", fontWeight: 600 }}
          >
            {test.subject}
          </span>
          <span
            className="text-xs px-2 py-0.5 rounded-full border"
            style={{
              background: "#f9fafb",
              color: "#6b7280",
              borderColor: "#e5e7eb",
              fontSize: "11px",
            }}
          >
            {test.type}
          </span>
        </div>
        {isTeacher && (
          <div className="relative shrink-0 -mt-1 -mr-1" ref={menuRef}>
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
              aria-label={`Menu for ${test.title}`}
            >
              <MoreHorizontal size={16} />
            </button>
            {menuOpen && (
              <div className="absolute right-0 top-full mt-1 w-32 bg-popover border border-border rounded-md shadow-md py-1 z-10">
                <button
                  onClick={() => {
                    setMenuOpen(false);
                    onEdit();
                  }}
                  className="w-full text-left px-3 py-1.5 text-sm hover:bg-muted text-foreground transition-colors"
                >
                  Edit
                </button>
                <button
                  onClick={() => {
                    setMenuOpen(false);
                    onDelete();
                  }}
                  className="w-full text-left px-3 py-1.5 text-sm hover:bg-muted text-rose-600 transition-colors"
                >
                  Delete
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Title */}
      <div>
        <h3 className="text-sm text-foreground leading-snug">
          {test.title}
        </h3>
      </div>

      {/* Progress bar (if in progress) */}
      <div>
        <div className="flex justify-between text-xs text-muted-foreground mb-1">
          <span>In progress</span>
          <span>{test.progress}%</span>
        </div>
        <div className="w-full h-1.5 bg-muted rounded-full">
          <div
            className="h-1.5 rounded-full transition-all"
            style={{
              width: `${test.progress}%`,
              background: "#1B7A5A",
            }}
          />
        </div>
      </div>

      {/* Stats */}
      <div className="flex items-center gap-3 text-xs text-muted-foreground">
        <span className="flex items-center gap-1">
          <BookOpen size={11} /> {test.questions}Q
        </span>
        <span className="flex items-center gap-1">
          <Clock size={11} /> {test.duration}m
        </span>
      </div>

      <p className="text-xs text-muted-foreground/70">
        Last attempted{" "}
        {test.lastAttempt ? test.lastAttempt : "None"}
      </p>

      {/* CTA */}
      {test.locked ? (
        <button
          disabled
          className="mt-auto flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs bg-muted text-muted-foreground cursor-not-allowed"
        >
          <Lock size={12} /> Unlock to Attempt
        </button>
      ) : isComplete ? (
        <button
          className="mt-auto flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs border transition-all group-hover:gap-2 duration-150"
          style={{
            borderColor: "#1B7A5A",
            color: "#1B7A5A",
            background: "#fff",
          }}
        >
          <RotateCcw size={12} /> Continue
        </button>
      ) : (
        <button
          className="mt-auto flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs text-[#1A1A1A] transition-all group-hover:gap-2 duration-150"
          style={{ background: "#E8C040" }}
        >
          <Play size={12} /> Start <ChevronRight size={13} />
        </button>
      )}
    </div>
  );
}


/* ── Teacher Question Editor ─────────────────────────────── */
function QuestionEditor({
  test,
  onBack,
  onUpdateQuestion,
  onDeleteQuestion,
}: {
  test: Test;
  onBack: () => void;
  onUpdateQuestion: (
    testId: number,
    questionId: number,
    field: keyof Omit<EditableQuestion, "id">,
    value: string,
  ) => void;
  onDeleteQuestion: (testId: number, questionId: number) => void;
}) {
  return (
    <div className="flex flex-col h-full bg-background overflow-hidden">
      <GlobalHeader
        title="Edit Questions"
        subtitle={`${test.title} · Teacher question editor`}
      />

      <div className="flex-1 overflow-y-auto p-8 pt-6">
        <div className="max-w-[980px] mx-auto space-y-5">
          <div className="bg-card border border-border rounded-xl p-5 flex items-center justify-between gap-4 sticky top-0 z-10 shadow-sm">
            <div className="min-w-0">
              <button
                onClick={onBack}
                className="inline-flex items-center gap-2 text-sm text-[#1B7A5A] hover:text-[#145f47] transition-colors mb-2"
              >
                <ArrowLeft size={15} /> Back to Test Bank
              </button>
              <h2 className="text-lg text-foreground truncate">{test.title}</h2>
              <p className="text-sm text-muted-foreground">
                Edit or delete questions one by one. Changes are saved in this demo session.
              </p>
            </div>
            <div className="hidden sm:flex items-center gap-2 rounded-full bg-[#E8F5EF] px-3 py-1.5 text-xs text-[#1B7A5A] border border-[#c2ddd4] shrink-0">
              <Save size={13} /> {test.editableQuestions.length} editable questions
            </div>
          </div>

          {test.editableQuestions.length === 0 ? (
            <div className="bg-card border border-border rounded-xl p-10 text-center text-muted-foreground">
              <BookOpen size={32} className="mx-auto mb-3 opacity-40" />
              <p className="text-sm">All questions have been deleted from this item.</p>
            </div>
          ) : (
            <div className="space-y-4 pb-8">
              {test.editableQuestions.map((question, index) => (
                <article
                  key={question.id}
                  className="bg-card border border-border rounded-xl p-5 shadow-sm"
                >
                  <div className="flex items-start justify-between gap-4 mb-4">
                    <div>
                      <p className="text-xs uppercase tracking-[0.12em] text-muted-foreground mb-1">
                        Question {index + 1}
                      </p>
                      <p className="text-sm text-foreground">Manual edit</p>
                    </div>
                    <button
                      onClick={() => onDeleteQuestion(test.id, question.id)}
                      className="inline-flex items-center gap-1.5 rounded-lg border border-rose-200 bg-rose-50 px-2.5 py-1.5 text-xs text-rose-700 hover:bg-rose-100 transition-colors"
                    >
                      <Trash2 size={13} /> Delete
                    </button>
                  </div>

                  <div className="space-y-4">
                    <label className="block">
                      <span className="block text-xs font-medium text-muted-foreground mb-1.5">
                        Question prompt
                      </span>
                      <textarea
                        value={question.prompt}
                        onChange={(event) =>
                          onUpdateQuestion(
                            test.id,
                            question.id,
                            "prompt",
                            event.target.value,
                          )
                        }
                        rows={4}
                        className="w-full resize-y rounded-lg border border-border bg-background px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-[#1B7A5A]/50 focus:border-[#1B7A5A]"
                      />
                    </label>

                    <div className="grid grid-cols-1 md:grid-cols-[180px_1fr] gap-4">
                      <label className="block">
                        <span className="block text-xs font-medium text-muted-foreground mb-1.5">
                          Correct answer
                        </span>
                        <input
                          value={question.answer}
                          onChange={(event) =>
                            onUpdateQuestion(
                              test.id,
                              question.id,
                              "answer",
                              event.target.value,
                            )
                          }
                          className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-[#1B7A5A]/50 focus:border-[#1B7A5A]"
                        />
                      </label>

                      <label className="block">
                        <span className="block text-xs font-medium text-muted-foreground mb-1.5">
                          Explanation
                        </span>
                        <textarea
                          value={question.explanation}
                          onChange={(event) =>
                            onUpdateQuestion(
                              test.id,
                              question.id,
                              "explanation",
                              event.target.value,
                            )
                          }
                          rows={3}
                          className="w-full resize-y rounded-lg border border-border bg-background px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-[#1B7A5A]/50 focus:border-[#1B7A5A]"
                        />
                      </label>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
