import React, { useState } from "react";
import StudentModal from "./StudentModal";
import {
  AlertTriangle,
  ArrowRight,
  Filter,
} from "lucide-react";

// Dữ liệu giả lập cho phần KPI
const kpiData = [
  {
    label: "AVERAGE SCORE",
    value: "78%",
    sub: "",
    color: "bg-[#1B7A5A]",
  },
  {
    label: "HIGHEST SCORE",
    value: "98%",
    sub: "",
    color: "bg-[#1B7A5A]",
  },
  {
    label: "LOWEST SCORE",
    value: "42%",
    sub: "",
    color: "bg-rose-600",
  },
  {
    label: "PARTICIPANTS",
    value: "24/25",
    sub: "1 Absent",
    color: "bg-transparent",
  },
  {
    label: "COMPLETION RATE",
    value: "96%",
    sub: "",
    color: "bg-[#1B7A5A]",
  },
  {
    label: "AVG. TIME",
    value: "42m 15s",
    sub: "Limit: 60m",
    color: "bg-transparent",
  },
];

// Dữ liệu giả lập cho Biểu đồ câu hỏi (15 câu để test scroll)
const questionData = [
  { id: "Q1", correct: 90, incorrect: 10 },
  { id: "Q2", correct: 85, incorrect: 15 },
  { id: "Q3", correct: 95, incorrect: 5 },
  { id: "Q4", correct: 35, incorrect: 65, isHard: true },
  { id: "Q5", correct: 80, incorrect: 20 },
  { id: "Q6", correct: 75, incorrect: 25 },
  { id: "Q7", correct: 45, incorrect: 55, isHard: true },
  { id: "Q8", correct: 88, incorrect: 12 },
  { id: "Q9", correct: 70, incorrect: 30 },
  { id: "Q10", correct: 82, incorrect: 18 },
  { id: "Q11", correct: 60, incorrect: 40 },
  { id: "Q12", correct: 92, incorrect: 8 },
  { id: "Q13", correct: 78, incorrect: 22 },
  { id: "Q14", correct: 50, incorrect: 50 },
  { id: "Q15", correct: 85, incorrect: 15 },
];

// Dữ liệu giả lập cho Bảng xếp hạng (Đã bỏ cột Rank)
const rankingData = [
  {
    name: "Eleanor Vance",
    avatar: "EV",
    score: "98%",
    time: "38m 12s",
    submitted: "Oct 12, 10:45 AM",
    scoreColor: "text-[#1B7A5A]",
  },
  {
    name: "Theodora Crain",
    avatar: "TC",
    score: "95%",
    time: "41m 05s",
    submitted: "Oct 12, 10:48 AM",
    scoreColor: "text-[#1B7A5A]",
  },
  {
    name: "Luke Sanderson",
    avatar: "LS",
    score: "92%",
    time: "39m 50s",
    submitted: "Oct 12, 10:46 AM",
    scoreColor: "text-[#1B7A5A]",
  },
  {
    name: "Arthur Dudley",
    avatar: "AD",
    score: "88%",
    time: "45m 20s",
    submitted: "Oct 12, 10:52 AM",
    scoreColor: "text-[#1B7A5A]",
  },
  {
    name: "Steven Montague",
    avatar: "SM",
    score: "42%",
    time: "58m 10s",
    submitted: "Oct 12, 11:05 AM",
    scoreColor: "text-rose-600",
    isAvatarGray: true,
  },
];

export default function TestPerformanceDashboard() {
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <div className="w-full animate-in fade-in slide-in-from-bottom-2 duration-300 font-sans">
      {/* ── 1. KPI CARDS ── */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6">
        {kpiData.map((kpi, idx) => (
          <div
            key={idx}
            className="bg-white border border-border/60 rounded-xl p-4 shadow-sm flex flex-col justify-between"
          >
            <span className="text-[10px] font-bold text-slate-500 tracking-wider mb-2">
              {kpi.label}
            </span>
            <div>
              <div className="text-2xl font-bold text-slate-800">
                {kpi.value}
              </div>
              {kpi.sub && (
                <div className="text-xs text-slate-400 mt-1">
                  {kpi.sub}
                </div>
              )}
              {kpi.color !== "bg-transparent" && (
                <div
                  className={`h-1 w-12 rounded-full mt-2 ${kpi.color}`}
                />
              )}
            </div>
          </div>
        ))}
      </div>

      {/* ── 2. MAIN GRID ── */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* ── CỘT TRÁI (8/12) ── */}
        <div className="lg:col-span-8 flex flex-col gap-6">
          {/* Question Performance Breakdown */}
          <div className="bg-white border border-border/60 rounded-xl shadow-sm overflow-hidden flex flex-col">
            <div className="p-5 border-b flex items-center justify-between bg-white z-10">
              <h2 className="text-md font-bold text-slate-800">
                Question Performance Breakdown
              </h2>
              <div className="flex items-center gap-4 text-xs font-medium">
                {/* Legend chỉnh lại màu đậm hơn để match với thanh bar */}
                <div className="flex items-center gap-1.5">
                  <div className="w-3 h-3 rounded-sm bg-[#115e43]" />{" "}
                  Correct
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-3 h-3 rounded-sm bg-[#b31919]" />{" "}
                  Incorrect
                </div>
              </div>
            </div>

            {/* Scroll Container */}
            <div className="p-5 max-h-[350px] overflow-y-auto pr-4 [&::-webkit-scrollbar]:w-2 [&::-webkit-scrollbar-track]:bg-slate-100 [&::-webkit-scrollbar-thumb]:bg-slate-300 [&::-webkit-scrollbar-thumb]:rounded-full">
              <div className="flex flex-col gap-4">
                {questionData.map((q) => (
                  <div
                    key={q.id}
                    className="flex items-center gap-4"
                  >
                    <span
                      className={`w-6 text-sm font-semibold ${q.isHard ? "text-amber-600" : "text-slate-600"}`}
                    >
                      {q.id}
                    </span>
                    <div className="flex-1 flex h-4 rounded-full overflow-hidden bg-slate-100">
                      {/* Cập nhật màu xanh đậm và đỏ đậm */}
                      <div
                        className="bg-[#115e43] h-full"
                        style={{ width: `${q.correct}%` }}
                      />
                      <div
                        className="bg-[#b31919] h-full"
                        style={{ width: `${q.incorrect}%` }}
                      />
                    </div>
                    <span
                      className={`w-10 text-right text-xs font-bold ${q.isHard ? "text-amber-600" : "text-slate-500"}`}
                    >
                      {q.correct}%
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Student Rankings (Đã bỏ cột Rank) */}
          <div className="bg-white border border-border/60 rounded-xl shadow-sm overflow-hidden flex flex-col">
            <div className="p-5 border-b flex items-center justify-between">
              <h2 className="text-md font-bold text-slate-800">
                Student Rankings
              </h2>
              <button className="flex items-center gap-1.5 text-xs font-medium text-[#1B7A5A] hover:bg-[#1B7A5A]/5 px-2 py-1 rounded transition-colors">
                <Filter size={14} /> Filter
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm whitespace-nowrap">
                <thead className="bg-slate-50/50 text-xs text-slate-500 font-semibold border-b">
                  <tr>
                    <th className="px-5 py-4">STUDENT NAME</th>
                    <th className="px-5 py-4 text-center">
                      SCORE
                    </th>
                    <th className="px-5 py-4 text-center">
                      COMPLETION TIME
                    </th>
                    <th className="px-5 py-4">SUBMITTED</th>
                    <th className="px-5 py-4 text-center">
                      ACTION
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/50">
                  {rankingData.map((student, idx) => (
                    <tr
                      key={idx}
                      className="hover:bg-slate-50/50 transition-colors"
                    >
                      <td className="px-5 py-4">
                        <div className="flex items-center gap-3">
                          <div
                            className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${student.isAvatarGray ? "bg-slate-200 text-slate-500" : "bg-slate-800 text-white"}`}
                          >
                            {student.avatar}
                          </div>
                          <span className="font-semibold text-slate-700">
                            {student.name}
                          </span>
                        </div>
                      </td>
                      <td
                        className={`px-5 py-4 text-center font-bold ${student.scoreColor}`}
                      >
                        {student.score}
                      </td>
                      <td className="px-5 py-4 text-center text-slate-600">
                        {student.time}
                      </td>
                      <td className="px-5 py-4 text-slate-500 text-xs">
                        {student.submitted
                          .split(",")
                          .map((line, i) => (
                            <div key={i}>{line}</div>
                          ))}
                      </td>
                      <td className="px-5 py-4 text-center">
                        <button
                          onClick={() => setIsModalOpen(true)}
                          className="text-[#1B7A5A] font-semibold text-xs hover:underline"
                        >
                          View
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="p-3 border-t bg-slate-50/50 text-center">
              <button className="text-xs font-bold text-[#1B7A5A] hover:underline">
                View Full Roster (24)
              </button>
            </div>
          </div>
        </div>

        {/* ── CỘT PHẢI (4/12) ── */}
        <div className="lg:col-span-4 flex flex-col gap-6">
          {/* Hardest Questions (Đã bỏ nền vàng, chuyển sang kẻ ngang) */}
          <div className="bg-white border border-border/60 rounded-xl shadow-sm p-5">
            <h2 className="text-md font-bold text-slate-800 flex items-center gap-2 mb-2 pb-3 border-b border-slate-300">
              <AlertTriangle
                size={18}
                className="text-amber-500"
              />{" "}
              Hardest Questions
            </h2>

            <div className="flex flex-col">
              {/* Question 1 */}
              <div className="py-4 border-b border-slate-300 flex items-start gap-3">
                <span className="bg-slate-100 text-slate-700 text-xs font-bold px-2 py-1 rounded">
                  Q4
                </span>
                <div>
                  <h3 className="text-sm font-bold text-slate-800 mb-1">
                    Logical Fallacies - Strawman
                  </h3>
                  <p className="text-xs text-slate-600 mb-2 leading-relaxed">
                    65% incorrect. Most selected distractor: C.
                  </p>
                  <button className="flex items-center gap-1 text-xs font-bold text-[#1B7A5A] hover:underline">
                    Review Question <ArrowRight size={12} />
                  </button>
                </div>
              </div>

              {/* Question 2 */}
              <div className="py-4 border-b border-border/60 last:border-0 flex items-start gap-3">
                <span className="bg-slate-100 text-slate-700 text-xs font-bold px-2 py-1 rounded">
                  Q7
                </span>
                <div>
                  <h3 className="text-sm font-bold text-slate-800 mb-1">
                    Author's Intent - Tone Shift
                  </h3>
                  <p className="text-xs text-slate-600 mb-2 leading-relaxed">
                    55% incorrect. Most selected distractor: A.
                  </p>
                  <button className="flex items-center gap-1 text-xs font-bold text-[#1B7A5A] hover:underline">
                    Review Question <ArrowRight size={12} />
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Score Distribution */}
          <div className="bg-white border border-border/60 rounded-xl shadow-sm p-5">
            <h2 className="text-md font-bold text-slate-800 flex items-center gap-2 mb-6">
              <div className="w-4 h-4 flex items-end gap-[2px]">
                <div className="w-1 h-2 bg-[#1B7A5A]" />
                <div className="w-1 h-4 bg-[#1B7A5A]" />
                <div className="w-1 h-3 bg-[#1B7A5A]" />
              </div>
              Score Distribution
            </h2>

            <div className="flex items-end justify-between h-32 mt-4 px-2">
              <div className="flex flex-col items-center gap-2 w-full">
                <div className="w-full bg-[#1B7A5A]/10 h-[10px] rounded-t-sm" />
                <span className="text-[10px] text-slate-500 font-medium">
                  &lt; 50%
                </span>
              </div>
              <div className="flex flex-col items-center gap-2 w-full">
                <div className="w-full bg-[#1B7A5A]/10 h-[15px] rounded-t-sm" />
                <span className="text-[10px] text-slate-500 font-medium">
                  60%
                </span>
              </div>
              <div className="flex flex-col items-center gap-2 w-full">
                <div className="w-full bg-[#1B7A5A]/30 h-[35px] rounded-t-sm" />
                <span className="text-[10px] text-slate-500 font-medium">
                  70%
                </span>
              </div>
              <div className="flex flex-col items-center gap-2 w-full">
                <div className="w-full bg-[#1B7A5A]/60 h-[50px] rounded-t-sm" />
                <span className="text-[10px] text-slate-500 font-medium">
                  80%
                </span>
              </div>
              <div className="flex flex-col items-center gap-2 w-full relative">
                <div className="w-full bg-[#1B7A5A]/80 h-[90px] rounded-t-sm" />
                <span className="text-[10px] text-slate-500 font-medium">
                  90%
                </span>
              </div>
              <div className="flex flex-col items-center gap-2 w-full">
                <div className="w-full bg-[#0F5A40] h-[30px] rounded-t-sm" />
                <span className="text-[10px] text-slate-500 font-medium">
                  100%
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
      {isModalOpen && (
        <StudentModal onClose={() => setIsModalOpen(false)} />
      )}
    </div>
  );
}