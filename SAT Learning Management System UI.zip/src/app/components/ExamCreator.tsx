import React, { useState } from "react";
import { 
  ArrowLeft, 
  ChevronRight, 
  Save, 
  Play, 
  CheckCircle2, 
  AlertCircle,
  FileText,
  Clock,
  BookOpen
} from "lucide-react";
import { GlobalHeader } from "./GlobalHeader";

interface ExamCreatorProps {
  onBack: () => void;
  initialData?: {
    title: string;
    subject: string;
    timeLimit: string;
    modules: string;
    content: string;
  } | null;
}

type Step = 1 | 2;

export function ExamCreator({ onBack, initialData }: ExamCreatorProps) {
  const [step, setStep] = useState<Step>(1);
  
  // Step 1 State
  const [title, setTitle] = useState(initialData?.title || "");
  const [subject, setSubject] = useState(initialData?.subject || "RW");
  const [timeLimit, setTimeLimit] = useState(initialData?.timeLimit || "64");
  const [modules, setModules] = useState(initialData?.modules || "2");

  // Step 2 State
  const [content, setContent] = useState(initialData?.content || "");
  const [parsed, setParsed] = useState(false);
  const [errors, setErrors] = useState<string[]>([]);
  const [showErrors, setShowErrors] = useState(false);
  const [expandErrors, setExpandErrors] = useState(false);

  const handleNext = () => {
    if (step === 1) setStep(2);
  };

  const handleBack = () => {
    if (step === 2) setStep(1);
    else onBack();
  };

  const handleParse = () => {
    // Mock parsing and validation
    setParsed(true);
    // Simulate some errors
    if (content.length > 0) {
      setErrors([
        "Question 3: Missing correct answer",
        "Question 4: Missing answer choice D",
        "Question 8: Invalid question numbering"
      ]);
      setShowErrors(true);
    } else {
      setErrors([]);
      setShowErrors(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-background overflow-hidden">
      <GlobalHeader 
        title="Create Exam" 
        subtitle="Create a new SAT exam or assignment" 
      />

      {/* Breadcrumb Stepper */}
      <div className="flex items-center gap-2 px-8 py-4 border-b border-border bg-card shrink-0">
        <button 
          onClick={onBack}
          className="p-1.5 mr-2 rounded-lg text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
        >
          <ArrowLeft size={18} />
        </button>
        <div className="flex items-center text-sm">
          <button 
            onClick={() => setStep(1)}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-full transition-colors ${
              step === 1 
                ? "bg-[#1B7A5A] text-white font-medium" 
                : "bg-muted text-muted-foreground hover:bg-muted/80"
            }`}
          >
            <span className="w-5 h-5 rounded-full bg-white/20 flex items-center justify-center text-xs">1</span>
            Exam Information
          </button>
          <ChevronRight size={16} className="mx-2 text-muted-foreground" />
          <button 
            onClick={() => step === 2 && setStep(2)}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-full transition-colors ${
              step === 2 
                ? "bg-[#1B7A5A] text-white font-medium" 
                : "bg-muted text-muted-foreground"
            } ${step === 1 ? "opacity-50 cursor-not-allowed" : ""}`}
          >
            <span className="w-5 h-5 rounded-full bg-black/10 dark:bg-white/10 flex items-center justify-center text-xs">2</span>
            Exam Content
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-hidden relative">
        {step === 1 ? (
          <div className="h-full overflow-y-auto p-8">
            <div className="max-w-2xl mx-auto space-y-8">
              <div className="space-y-2">
                <h2 className="text-2xl font-semibold tracking-tight text-foreground">Exam Details</h2>
                <p className="text-sm text-muted-foreground">Basic information for the new SAT practice test or assignment.</p>
              </div>

              <div className="space-y-5 bg-card border border-border rounded-xl p-6 shadow-sm">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Exam Title</label>
                  <input 
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. SAT Practice Test 10"
                    className="w-full px-3 py-2 rounded-lg border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-[#1B7A5A]/50 focus:border-[#1B7A5A]"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Subject</label>
                  <div className="grid grid-cols-2 gap-3">
                    {["RW", "Math"].map((s) => (
                      <button
                        key={s}
                        onClick={() => setSubject(s)}
                        className={`flex items-center justify-center gap-2 py-2.5 rounded-lg border text-sm font-medium transition-colors ${
                          subject === s
                            ? "bg-[#E8F5EF] border-[#1B7A5A] text-[#1B7A5A]"
                            : "bg-background border-border text-foreground hover:bg-muted"
                        }`}
                      >
                        {s === "RW" ? <BookOpen size={16} /> : <FileText size={16} />}
                        {s === "RW" ? "Reading & Writing" : "Math"}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-5">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground">Time Limit (minutes)</label>
                    <div className="relative">
                      <Clock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                      <input 
                        type="number"
                        value={timeLimit}
                        onChange={(e) => setTimeLimit(e.target.value)}
                        className="w-full pl-9 pr-3 py-2 rounded-lg border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-[#1B7A5A]/50 focus:border-[#1B7A5A]"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground">Number of Modules</label>
                    <input 
                      type="number"
                      value={modules}
                      onChange={(e) => setModules(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-[#1B7A5A]/50 focus:border-[#1B7A5A]"
                    />
                  </div>
                </div>
              </div>

              <div className="flex justify-end pt-4">
                <button 
                  onClick={handleNext}
                  className="flex items-center gap-2 px-5 py-2.5 bg-[#E8C040] text-[#1A1A1A] font-medium rounded-lg hover:brightness-105 transition-all"
                >
                  Next: Exam Content <ChevronRight size={18} />
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex h-full divide-x divide-border">
            {/* Left Panel: Editor */}
            <div className="flex-1 flex flex-col h-full bg-background">
              <div className="flex items-center justify-between px-5 py-3 border-b border-border bg-card shrink-0">
                <h3 className="text-sm font-medium flex items-center gap-2">
                  <FileText size={16} className="text-[#1B7A5A]" />
                  Exam Input Editor
                </h3>
                <div className="flex items-center gap-2">
                  <button 
                    className="px-3 py-1.5 text-xs font-medium border border-border rounded-md hover:bg-muted transition-colors"
                  >
                    Save Draft
                  </button>
                  <button 
                    onClick={handleParse}
                    className="px-3 py-1.5 text-xs font-medium bg-[#1B7A5A] text-white rounded-md hover:bg-[#145f47] transition-colors"
                  >
                    Parse Content
                  </button>
                </div>
              </div>
              
              <div className="flex-1 p-5 flex flex-col h-full overflow-hidden">
                <p className="text-xs text-muted-foreground mb-3 shrink-0">
                  Paste your raw exam content here. Use standard numbering for questions and letters (A, B, C, D) for choices.
                </p>
                <textarea 
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="1. What is the main idea of the passage?
A) The author's view on society.
B) The historical context of the event.
C) The underlying economic principles.
D) The character's internal conflict.
Answer: A

..."
                  className="flex-1 w-full p-4 rounded-xl border border-border bg-card text-sm font-mono leading-relaxed resize-none focus:outline-none focus:ring-2 focus:ring-[#1B7A5A]/50 focus:border-[#1B7A5A]"
                />
              </div>
            </div>

            {/* Right Panel: Preview & Validation */}
            <div className="flex-1 flex flex-col h-full bg-muted/30">
              <div className="flex items-center justify-between px-5 py-3 border-b border-border bg-card shrink-0">
                <h3 className="text-sm font-medium flex items-center gap-2">
                  <Play size={16} className="text-[#E8C040]" />
                  Live Preview
                </h3>
                <button className="px-4 py-1.5 text-xs font-medium bg-foreground text-background rounded-md hover:bg-foreground/90 transition-colors">
                  Publish Exam
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-5 space-y-4">
                {/* Validation Panel */}
                {parsed && showErrors && errors.length > 0 && (
                  <div className="bg-rose-50 border border-rose-200 rounded-xl overflow-hidden shadow-sm mb-6">
                    <button 
                      onClick={() => setExpandErrors(!expandErrors)}
                      className="w-full flex items-center justify-between p-4 bg-rose-50 hover:bg-rose-100/50 transition-colors"
                    >
                      <div className="flex items-center gap-2 text-rose-700 font-medium">
                        <AlertCircle size={18} />
                        {errors.length} Issues Detected
                      </div>
                      <ChevronRight 
                        size={18} 
                        className={`text-rose-500 transition-transform ${expandErrors ? "rotate-90" : ""}`} 
                      />
                    </button>
                    
                    {expandErrors && (
                      <div className="p-4 pt-0 border-t border-rose-100 bg-rose-50">
                        <ul className="space-y-2 mt-2">
                          {errors.map((error, idx) => (
                            <li 
                              key={idx} 
                              className="text-sm text-rose-600 bg-white/60 px-3 py-2 rounded-lg cursor-pointer hover:bg-white transition-colors border border-rose-100 flex items-start gap-2"
                              title="Click to jump to question"
                            >
                              <span className="w-1.5 h-1.5 rounded-full bg-rose-500 mt-1.5 shrink-0" />
                              {error}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                )}
                
                {parsed && errors.length === 0 && content.length > 0 && (
                  <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 shadow-sm mb-6 flex items-center gap-3 text-emerald-700">
                    <CheckCircle2 size={18} />
                    <span className="text-sm font-medium">All content parsed successfully. No errors detected.</span>
                  </div>
                )}

                {/* Live Preview Content */}
                <div className="bg-card border border-border rounded-xl shadow-sm min-h-[400px]">
                  {content.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-muted-foreground p-10 opacity-50">
                      <FileText size={48} className="mb-4" />
                      <p>Enter and parse content to see preview.</p>
                    </div>
                  ) : (
                    <div className="p-8 space-y-8">
                      {/* Mock Student Interface Render */}
                      <div className="border-b border-border pb-4">
                        <p className="text-sm font-medium text-muted-foreground mb-4">Question 1</p>
                        <p className="text-base text-foreground leading-relaxed mb-6">
                          While reading a long passage, the student notices that the author frequently uses metaphorical language. Which of the following best describes the effect of this language?
                        </p>
                        <div className="space-y-3">
                          {["It clarifies technical concepts.", "It creates a sense of urgency.", "It illustrates abstract ideas.", "It confuses the reader."].map((choice, i) => (
                            <label key={i} className="flex items-center gap-3 p-3 rounded-lg border border-border hover:border-[#1B7A5A] cursor-pointer transition-colors">
                              <div className="w-6 h-6 rounded-full border border-border flex items-center justify-center text-xs font-medium text-muted-foreground">
                                {String.fromCharCode(65 + i)}
                              </div>
                              <span className="text-sm text-foreground">{choice}</span>
                            </label>
                          ))}
                        </div>
                      </div>
                      
                      <div className="border-b border-border pb-4 opacity-50">
                        <p className="text-sm font-medium text-muted-foreground mb-4">Question 2</p>
                        <p className="text-base text-foreground leading-relaxed mb-6">
                          ... More content preview based on input ...
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
