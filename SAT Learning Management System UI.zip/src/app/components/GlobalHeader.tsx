import { Bell, Flame } from "lucide-react";
import React from "react";

interface HeaderProps {
  title: React.ReactNode;
  subtitle?: React.ReactNode;
  centerContent?: React.ReactNode;
}

export function GlobalHeader({ title, subtitle, centerContent }: HeaderProps) {
  return (
    <header className="sticky top-0 z-10 flex h-[60px] items-center justify-between border-b border-border bg-card px-6 shrink-0">
      {/* Left */}
      <div className="flex w-[280px] flex-col justify-center">
        <h1 className="text-base font-semibold text-foreground leading-tight">{title}</h1>
        {subtitle && (
          <p className="text-xs text-muted-foreground mt-0.5 leading-tight truncate">
            {subtitle}
          </p>
        )}
      </div>

      {/* Center */}
      <div className="flex flex-1 items-center justify-center h-full">
        {centerContent}
      </div>

      {/* Right */}
      <div className="flex w-[280px] items-center justify-end gap-5">
        {/* Streak Indicator */}
        <div className="flex items-center gap-1.5 cursor-pointer">
          <Flame size={18} className="text-orange-500 fill-orange-500" />
          <span className="text-sm font-bold text-foreground">12</span>
        </div>

        {/* Notifications */}
        <button className="relative text-muted-foreground hover:text-foreground transition-colors">
          <Bell size={20} />
          <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5 rounded-full bg-red-500 ring-2 ring-card" />
        </button>

        {/* User Avatar */}
        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#1B7A5A] text-xs font-semibold text-white cursor-pointer select-none ring-2 ring-offset-2 ring-offset-card ring-transparent hover:ring-[#1B7A5A]/30 transition-all">
          NL
        </div>
      </div>
    </header>
  );
}
