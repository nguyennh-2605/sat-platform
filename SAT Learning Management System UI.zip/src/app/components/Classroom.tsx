import { useState } from "react";
import {
  Bell,
  Users,
  GitBranch,
  Copy,
  Check,
  Plus,
  X,
  FileText,
  BookOpen,
  ChevronDown,
  ChevronRight,
  CalendarDays,
  UploadCloud,
  TrendingUp,
  CheckCircle2,
  Clock,
  ExternalLink,
  ClipboardList,
  Calendar,
  AlertTriangle,
  Megaphone,
  Edit3,
  Trash2,
  Download,
  Settings,
  HelpCircle,
  FileQuestion,
  Lock as LockIcon,
} from "lucide-react";
import AssignmentDetailTeacherView from "./AssignmentDetailTeacherView";
import AssignmentDetailStudentView from "./AssignmentDetailStudentView";
import TestPerformanceDashboard from "./TestPerformanceDashboard";

type ClassTab = "notifications" | "members" | "timeline";

/* ── Notifications ─────────────────────────────────────── */
interface NotificationItem {
  id: number;
  type: "assignment" | "announcement";
  title: string;
  body: string;
  time: string;
  badgeText: string;
  dueDate?: string;
  eventTime?: string;
  read: boolean;
}

const initialNotifications: NotificationItem[] = [
  {
    id: 1,
    type: "assignment",
    badgeText: "ASSIGNMENT",
    title: "Practice Test #4: Command of Evidence",
    body: "The new practice test covering Command of Evidence is now available. Please complete all sections before the deadline. Focus on analyzing t...",
    time: "2 hours ago",
    dueDate: "Due Oct 28",
    read: false,
  },
  {
    id: 2,
    type: "announcement",
    badgeText: "ANNOUNCEMENT",
    title: "Guest Lecture: Dr. Aris on Rhetoric",
    body: "We are honored to have Dr. Aris join us tomorrow to discuss advanced rhetorical strategies. Attendance is mandatory for Section A students. Please prepare 2 questions.",
    time: "5 hours ago",
    eventTime: "Tomorrow, 10:00 AM",
    read: true,
  },
  {
    id: 3,
    type: "assignment",
    badgeText: "ASSIGNMENT",
    title: "Vocabulary Drill 5",
    body: "Review the words from Chapter 4. Pay special attention to contextual usage rather than rote memorization. The quiz will include passage-...",
    time: "Yesterday",
    dueDate: "Due Nov 2",
    read: false,
  },
  {
    id: 4,
    type: "announcement",
    badgeText: "ANNOUNCEMENT",
    title: "Classroom Policy Update regarding Late Submissions",
    body: "Please review the updated policy document regarding late assignment submissions. A 10% penalty will now apply per day late unless prior authorization is granted.",
    time: "Oct 24",
    read: true,
  },
];

/* ── Members ───────────────────────────────────────────── */
interface Member {
  id: number;
  name: string;
  initials: string;
  color: string;
  status: "active" | "inactive" | "pending";
  avgScore: number;
  tests: number;
  joined: string;
}

const members: Member[] = [
  {
    id: 1,
    name: "Nguyễn Linh",
    initials: "NL",
    color: "#1B7A5A",
    status: "active",
    avgScore: 1340,
    tests: 12,
    joined: "Jan 2026",
  },
  {
    id: 2,
    name: "Trần Minh Đức",
    initials: "TD",
    color: "#0F4D38",
    status: "active",
    avgScore: 1280,
    tests: 10,
    joined: "Jan 2026",
  },
  {
    id: 3,
    name: "Lê Thị Hương",
    initials: "LH",
    color: "#2a9d6e",
    status: "active",
    avgScore: 1320,
    tests: 11,
    joined: "Feb 2026",
  },
  {
    id: 4,
    name: "Phạm Quốc Bảo",
    initials: "PB",
    color: "#b45309",
    status: "inactive",
    avgScore: 1190,
    tests: 6,
    joined: "Feb 2026",
  },
  {
    id: 5,
    name: "Hoàng Thu Thảo",
    initials: "HT",
    color: "#be185d",
    status: "active",
    avgScore: 1370,
    tests: 14,
    joined: "Jan 2026",
  },
  {
    id: 6,
    name: "Vũ Ngọc Anh",
    initials: "VA",
    color: "#0369a1",
    status: "pending",
    avgScore: 0,
    tests: 0,
    joined: "Jun 2026",
  },
  {
    id: 7,
    name: "Đặng Tuấn Kiệt",
    initials: "DK",
    color: "#4338ca",
    status: "active",
    avgScore: 1250,
    tests: 8,
    joined: "Mar 2026",
  },
  {
    id: 8,
    name: "Bùi Khánh Linh",
    initials: "BL",
    color: "#9d174d",
    status: "active",
    avgScore: 1295,
    tests: 9,
    joined: "Mar 2026",
  },
];

/* ── Timeline ──────────────────────────────────────────── */
interface WeekNode {
  week: number;
  label: string;
  dates: string;
  documents: { name: string; type: string }[];
  tests: { id: string; title: string; due: string }[];
  completed?: boolean;
}

const timeline: WeekNode[] = [
  {
    week: 1,
    label: "Foundations",
    dates: "Mar 3–9",
    documents: [
      { name: "SAT Overview Guide.pdf", type: "pdf" },
      { name: "Study Schedule Template.xlsx", type: "xlsx" },
    ],
    tests: [
      {
        id: "3",
        title: "Reading Comprehension Sprint",
        due: "Mar 9",
      },
    ],
    completed: true,
  },
  {
    week: 2,
    label: "Math Basics",
    dates: "Mar 10–16",
    documents: [{ name: "Algebra Notes.pdf", type: "pdf" }],
    tests: [
      { id: "2", title: "Math — Algebra Focus", due: "Mar 16" },
    ],
    completed: true,
  },
  {
    week: 3,
    label: "Reading Deep-Dive",
    dates: "Mar 17–23",
    documents: [
      { name: "Passage Strategies.pdf", type: "pdf" },
      { name: "Evidence-Based Reading.pdf", type: "pdf" },
    ],
    tests: [
      {
        id: "3",
        title: "Reading Comprehension Sprint",
        due: "Mar 23",
      },
    ],
    completed: true,
  },
  {
    week: 4,
    label: "Writing & Grammar",
    dates: "Mar 24–30",
    documents: [
      { name: "Grammar Rules Summary.pdf", type: "pdf" },
    ],
    tests: [
      {
        id: "4",
        title: "RW — Writing & Language Grammar",
        due: "Mar 30",
      },
    ],
    completed: true,
  },
  {
    week: 5,
    label: "Full Test #1",
    dates: "Mar 31–Apr 6",
    documents: [],
    tests: [
      {
        id: "6",
        title: "SAT Full Practice Test #7",
        due: "Apr 5",
      },
    ],
    completed: true,
  },
  {
    week: 6,
    label: "Mistakes Review",
    dates: "Apr 7–13",
    documents: [
      { name: "Mistakes Analysis Template.pdf", type: "pdf" },
    ],
    tests: [],
    completed: false,
  },
  {
    week: 7,
    label: "Advanced Math",
    dates: "Apr 14–20",
    documents: [
      { name: "Quadratics & Functions.pdf", type: "pdf" },
    ],
    tests: [
      {
        id: "5",
        title: "Math — Advanced Quadratics",
        due: "Apr 20",
      },
    ],
    completed: false,
  },
  {
    week: 8,
    label: "Full Test #2",
    dates: "Apr 21–27",
    documents: [],
    tests: [
      {
        id: "1",
        title: "SAT Full Practice Test #8",
        due: "Apr 26",
      },
    ],
    completed: false,
  },
];

/* ── Assignment stats ──────────────────────────────────── */
const assignmentStats: Record<
  string,
  {
    completion: number;
    avgScore: number;
    students: {
      name: string;
      initials: string;
      color: string;
      completed: boolean;
      score?: number;
      submittedAt?: string;
    }[];
  }
> = {
  "1": {
    completion: 75,
    avgScore: 1318,
    students: [
      {
        name: "Nguyễn Linh",
        initials: "NL",
        color: "#1B7A5A",
        completed: true,
        score: 1340,
        submittedAt: "Apr 26",
      },
      {
        name: "Trần Minh Đức",
        initials: "TD",
        color: "#0F4D38",
        completed: true,
        score: 1280,
        submittedAt: "Apr 26",
      },
      {
        name: "Lê Thị Hương",
        initials: "LH",
        color: "#2a9d6e",
        completed: true,
        score: 1310,
        submittedAt: "Apr 27",
      },
      {
        name: "Phạm Quốc Bảo",
        initials: "PB",
        color: "#b45309",
        completed: false,
      },
      {
        name: "Hoàng Thu Thảo",
        initials: "HT",
        color: "#be185d",
        completed: true,
        score: 1370,
        submittedAt: "Apr 25",
      },
      {
        name: "Đặng Tuấn Kiệt",
        initials: "DK",
        color: "#4338ca",
        completed: false,
      },
      {
        name: "Bùi Khánh Linh",
        initials: "BL",
        color: "#9d174d",
        completed: true,
        score: 1290,
        submittedAt: "Apr 26",
      },
    ],
  },
};

import { GlobalHeader } from "./GlobalHeader";
import { useAuth } from "../AuthContext";

function InviteCodeWidget() {
  const [copied, setCopied] = useState(false);
  const code = "ANT11A-2026";
  const handleCopy = () => {
    setCopied(true);
    navigator.clipboard.writeText(code); // Thêm hàm copy thật cho xịn
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      className="flex items-center justify-between gap-2 px-3 py-1.5 rounded-xl border w-full max-w-[280px]"
      style={{
        background: "#E8F5EF",
        borderColor: "#c2ddd4",
      }}
    >
      <div>
        <p className="text-[10px] uppercase tracking-wider font-semibold text-[#1B7A5A]/70">
          Class Invite Code
        </p>
        <p
          className="text-sm tracking-widest mt-0.5"
          style={{
            fontWeight: 700,
            fontFamily: "monospace",
            color: "#1B7A5A",
          }}
        >
          {code}
        </p>
      </div>
      <button
        onClick={handleCopy}
        className="p-1.5 rounded-lg transition-all hover:bg-[#1B7A5A]/20"
        style={{
          background: "rgba(27,122,90,0.12)",
          color: "#1B7A5A",
        }}
      >
        {copied ? <Check size={13} /> : <Copy size={13} />}
      </button>
    </div>
  );
}

export function Classroom() {
  const [tab, setTab] = useState<ClassTab>("notifications");

  const tabs: {
    id: ClassTab;
    label: string;
    icon: React.ReactNode;
  }[] = [
    {
      id: "notifications",
      label: "Notifications",
      icon: <Bell size={14} />,
    },
    {
      id: "members",
      label: "Members",
      icon: <Users size={14} />,
    },
    {
      id: "timeline",
      label: "Progress Timeline",
      icon: <GitBranch size={14} />,
    },
  ];

  return (
    <div className="flex flex-col h-full bg-background overflow-hidden">
      <GlobalHeader
        title="Classroom"
        subtitle="Class 11A"
        centerContent={
          <div className="flex h-full gap-2">
            {tabs.map((t) => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`flex items-center gap-1.5 px-4 h-full text-sm border-b-2 transition-all ${
                  tab === t.id
                    ? "border-[#1B7A5A] text-[#1B7A5A] font-medium"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                }`}
              >
                {t.icon}
                {t.label}
              </button>
            ))}
          </div>
        }
      />

      <div className="flex-1 overflow-y-auto">
        <div className="max-w-[1200px] mx-auto">
          {tab === "notifications" && <NotificationsTab />}
          {tab === "members" && <MembersTab />}
          {tab === "timeline" && <TimelineTab />}
        </div>
      </div>
    </div>
  );
}

/* ── Notifications Tab ─────────────────────────────────── */
function NotificationsTab() {
  const { role } = useAuth();
  // 3. Các State quản lý dữ liệu và bộ lọc
  const [notifications] = useState<NotificationItem[]>(
    initialNotifications,
  );
  const [activeFilter, setActiveFilter] = useState<
    "all" | "assignment" | "announcement"
  >("all");

  const typeConfig: Record<
    string,
    {
      bg: string;
      text: string;
      iconBg: string;
      icon: React.ReactNode;
    }
  > = {
    assignment: {
      bg: "#E8F5EF",
      text: "#1B7A5A",
      iconBg: "#c2ddd4",
      icon: (
        <ClipboardList size={16} style={{ color: "#1B7A5A" }} />
      ),
    },
    announcement: {
      bg: "#FEF9E7",
      text: "#92640a",
      iconBg: "#f0d070",
      icon: (
        <Megaphone size={16} style={{ color: "#92640a" }} />
      ),
    },
  };

  // Logic lọc danh sách dựa trên tab đang chọn
  const filteredNotifications = notifications.filter((n) => {
    if (activeFilter === "all") return true;
    return n.type === activeFilter;
  });

  return (
    <div className="p-8 bg-background font-sans">
      <div className="max-w-[1200px] mx-auto flex flex-col gap-6">
        {/* Nút Add Announcement nằm góc trên cùng bên phải */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Cột trái (4 cột): Chứa Class Code nằm thẳng hàng dọc với nhóm bộ lọc */}
          <div className="lg:col-span-4 flex justify-start w-full">
            {role === "teacher" && <InviteCodeWidget />}
          </div>

          {/* Cột phải (8 cột): Đẩy nút New Announcement sát lề phải, ngang hàng Class Code */}
          <div className="lg:col-span-8 flex justify-end w-full">
            {role === "teacher" && (
              <button className="flex items-center gap-2 bg-[#024D35] hover:bg-[#013826] text-white text-xs font-semibold px-4 py-2 rounded-lg transition-all shadow-sm">
                <Plus size={14} /> New Announcement
              </button>
            )}
          </div>
        </div>

        {/* Bố cục chính chia làm 2 cột theo đúng ảnh mẫu */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* CỘT TRÁI: Gồm nhóm Filter và khối Needs Attention */}
          <div className="lg:col-span-4 flex flex-col gap-6">
            {/* Hộp điều hướng bộ lọc (Navigation Tabs) */}
            <div className="bg-card border border-border rounded-xl p-3 flex flex-col gap-1 shadow-sm">
              <button
                onClick={() => setActiveFilter("all")}
                className={`flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-medium transition-all ${
                  activeFilter === "all"
                    ? "bg-muted text-foreground"
                    : "text-muted-foreground hover:bg-muted/50"
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Bell size={14} />
                  <span>All Notifications</span>
                </div>
                <span className="bg-muted-foreground/10 px-2 py-0.5 rounded-full text-[11px] font-semibold">
                  12
                </span>
              </button>

              <button
                onClick={() => setActiveFilter("assignment")}
                className={`flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-medium transition-all ${
                  activeFilter === "assignment"
                    ? "bg-muted text-foreground"
                    : "text-muted-foreground hover:bg-muted/50"
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <ClipboardList size={14} />
                  <span>Assignments</span>
                </div>
                <span className="bg-muted-foreground/10 px-2 py-0.5 rounded-full text-[11px] font-semibold">
                  8
                </span>
              </button>

              <button
                onClick={() => setActiveFilter("announcement")}
                className={`flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-medium transition-all ${
                  activeFilter === "announcement"
                    ? "bg-muted text-foreground"
                    : "text-muted-foreground hover:bg-muted/50"
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Megaphone size={14} />
                  <span>Announcements</span>
                </div>
                <span className="bg-muted-foreground/10 px-2 py-0.5 rounded-full text-[11px] font-semibold">
                  4
                </span>
              </button>
            </div>

            {/* Khối hiển thị Needs Attention */}
            <div className="bg-card border border-border rounded-xl p-5 shadow-sm relative overflow-hidden">
              <div className="absolute top-0 right-0 w-24 h-24 bg-[#E8F5EF] rounded-bl-full opacity-60 pointer-events-none" />

              <h3 className="text-sm font-bold text-foreground mb-4 relative z-10">
                Needs Attention
              </h3>

              <div className="flex flex-col gap-4 relative z-10">
                <div className="flex gap-3 border-l-2 border-rose-500 pl-3">
                  <div className="flex flex-col gap-0.5">
                    <p className="text-xs font-semibold text-foreground">
                      Practice Test #4
                    </p>
                    <span className="text-[11px] font-medium text-rose-600 flex items-center gap-1">
                      <AlertTriangle size={11} /> Due Today
                    </span>
                  </div>
                </div>

                <div className="flex gap-3 border-l-2 border-amber-500 pl-3">
                  <div className="flex flex-col gap-0.5">
                    <p className="text-xs font-semibold text-foreground">
                      Vocabulary Drill 5
                    </p>
                    <span className="text-[11px] font-medium text-muted-foreground flex items-center gap-1">
                      <Clock size={11} /> Due Nov 2
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* CỘT PHẢI: Danh sách các thẻ thông báo chính */}
          <div className="lg:col-span-8 flex flex-col gap-4">
            {filteredNotifications.map((n) => {
              const cfg =
                typeConfig[n.type] || typeConfig["assignment"];
              return (
                <div
                  key={n.id}
                  className={`bg-card border rounded-xl p-5 flex gap-4 transition-all hover:shadow-md border-l-4 ${
                    n.type === "assignment"
                      ? "border-l-[#1B7A5A]"
                      : "border-l-transparent"
                  } border-border shadow-sm`}
                >
                  {/* Icon tròn phía bên trái của Card */}
                  <div className="shrink-0">
                    <div
                      className="w-9 h-9 rounded-full flex items-center justify-center"
                      style={{ background: cfg.bg }}
                    >
                      {cfg.icon}
                    </div>
                  </div>

                  {/* Nội dung chi tiết của Card bên phải */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <span
                        className="text-[10px] font-bold tracking-wider"
                        style={{ color: cfg.text }}
                      >
                        {n.badgeText}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {n.time}
                      </span>
                    </div>

                    <h4 className="text-sm font-bold text-foreground mt-1 leading-snug">
                      {n.title}
                    </h4>

                    <p className="text-xs text-muted-foreground/90 mt-1.5 leading-relaxed">
                      {n.body}
                    </p>

                    {/* Phần chân Card (Dành cho thông báo có lịch Hạn nộp / Thời gian sự kiện) */}
                    {n.dueDate && (
                      <div className="mt-4 flex items-center justify-between border-t border-border/60 pt-3">
                        <div className="flex items-center gap-1.5 text-xs font-semibold text-rose-600">
                          <Calendar
                            size={13}
                            className="text-rose-500"
                          />
                          <span>{n.dueDate}</span>
                        </div>
                        <button className="text-xs font-bold text-[#1B7A5A] hover:underline flex items-center gap-1">
                          View Assignment{" "}
                          <ChevronRight size={14} />
                        </button>
                      </div>
                    )}

                    {n.eventTime && (
                      <div className="mt-4 flex items-center justify-between border-t border-border/60 pt-3">
                        <div className="flex items-center gap-1.5 text-xs font-medium text-foreground bg-muted px-2.5 py-1 rounded-md">
                          <Calendar
                            size={13}
                            className="text-muted-foreground"
                          />
                          <span>{n.eventTime}</span>
                        </div>
                        <button className="text-xs font-bold text-[#1B7A5A] hover:underline flex items-center gap-1">
                          Read More <ChevronRight size={14} />
                        </button>
                      </div>
                    )}

                    {!n.dueDate && !n.eventTime && (
                      <div className="mt-4 flex justify-end border-t border-border/60 pt-3">
                        <button className="text-xs font-bold text-[#1B7A5A] hover:underline flex items-center gap-1">
                          Read More <ChevronRight size={14} />
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}

            {/* Nút Load Older Notifications ở dưới cùng */}
            <div className="flex justify-center mt-2">
              <button className="text-xs font-semibold text-muted-foreground border border-border bg-card px-5 py-2 rounded-full hover:bg-muted transition-all shadow-sm">
                Load Older Notifications
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ── Members Tab ───────────────────────────────────────── */
function MembersTab() {
  const { role } = useAuth();
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [copied, setCopied] = useState(false);
  const handleCopy = () => {
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const statusStyle: Record<string, React.CSSProperties> = {
    active: {
      background: "#E8F5EF",
      color: "#1B7A5A",
      border: "1px solid #c2ddd4",
    },
    inactive: {
      background: "#f3f4f6",
      color: "#6b7280",
      border: "1px solid #e5e7eb",
    },
    pending: {
      background: "#FEF9E7",
      color: "#92640a",
      border: "1px solid #f0d070",
    },
  };

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-5">
        <p className="text-sm text-muted-foreground">
          {members.length} members enrolled
        </p>
        {role === "teacher" && (
          <button
            onClick={() => setShowInviteModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm text-white transition-colors hover:opacity-90"
            style={{ background: "#1B7A5A" }}
          >
            <Plus size={14} /> Invite Student
          </button>
        )}
      </div>

      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border bg-muted/40">
              <th
                className="text-left px-5 py-3 text-xs text-muted-foreground"
                style={{ fontWeight: 500 }}
              >
                Student
              </th>
              <th
                className="text-left px-4 py-3 text-xs text-muted-foreground"
                style={{ fontWeight: 500 }}
              >
                Status
              </th>
              <th
                className="text-right px-4 py-3 text-xs text-muted-foreground"
                style={{ fontWeight: 500 }}
              >
                Avg Score
              </th>
              <th
                className="text-right px-4 py-3 text-xs text-muted-foreground"
                style={{ fontWeight: 500 }}
              >
                Tests Done
              </th>
              <th
                className="text-right px-5 py-3 text-xs text-muted-foreground"
                style={{ fontWeight: 500 }}
              >
                Joined
              </th>
              {role === "teacher" && (
                <th
                  className="text-center px-4 py-3 text-xs text-muted-foreground"
                  style={{ fontWeight: 500 }}
                >
                  Actions
                </th>
              )}
            </tr>
          </thead>
          <tbody>
            {members.map((m, i) => (
              <tr
                key={m.id}
                className={`hover:bg-muted/30 transition-colors ${i !== members.length - 1 ? "border-b border-border" : ""}`}
              >
                <td className="px-5 py-3">
                  <div className="flex items-center gap-2.5">
                    <div
                      className="w-7 h-7 rounded-full flex items-center justify-center text-xs text-white shrink-0"
                      style={{
                        background: m.color,
                        fontWeight: 600,
                      }}
                    >
                      {m.initials}
                    </div>
                    <span
                      className="text-foreground"
                      style={{ fontWeight: 500 }}
                    >
                      {m.name}
                    </span>
                  </div>
                </td>
                <td className="px-4 py-3">
                  <span
                    className="text-xs px-2 py-0.5 rounded-full"
                    style={statusStyle[m.status]}
                  >
                    {m.status.charAt(0).toUpperCase() +
                      m.status.slice(1)}
                  </span>
                </td>
                <td
                  className="px-4 py-3 text-right text-foreground"
                  style={{
                    fontFamily: "monospace",
                    fontWeight: 500,
                  }}
                >
                  {m.avgScore > 0 ? m.avgScore : "—"}
                </td>
                <td className="px-4 py-3 text-right text-muted-foreground">
                  {m.tests}
                </td>
                <td className="px-5 py-3 text-right text-muted-foreground text-xs">
                  {m.joined}
                </td>
                {role === "teacher" && (
                  <td className="px-4 py-3 text-center">
                    <button className="text-muted-foreground hover:text-[#1B7A5A] transition-colors p-1.5 rounded-lg hover:bg-[#1B7A5A]/10">
                      <Edit3 size={14} />
                    </button>
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Invite Modal */}
      {showInviteModal && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-card border border-border rounded-2xl p-6 w-[400px] shadow-xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-foreground">
                Invite a Student
              </h3>
              <button
                onClick={() => setShowInviteModal(false)}
                className="p-1 rounded-lg hover:bg-muted text-muted-foreground"
              >
                <X size={16} />
              </button>
            </div>
            <p className="text-sm text-muted-foreground mb-4">
              Share the invite link or class code with your
              student.
            </p>

            <div className="mb-3">
              <label className="text-xs text-muted-foreground mb-1 block">
                Invitation Link
              </label>
              <div className="flex items-center gap-2 bg-muted rounded-lg px-3 py-2">
                <p
                  className="text-xs text-foreground flex-1 truncate"
                  style={{ fontFamily: "monospace" }}
                >
                  https://antacademy.vn/join/ANT11A-2026
                </p>
                <button
                  onClick={handleCopy}
                  style={{ color: "#1B7A5A" }}
                >
                  {copied ? (
                    <Check size={13} />
                  ) : (
                    <Copy size={13} />
                  )}
                </button>
              </div>
            </div>

            <div className="mb-5">
              <label className="text-xs text-muted-foreground mb-1 block">
                Class Code
              </label>
              <div
                className="flex items-center justify-center rounded-xl py-4 border"
                style={{
                  background: "#E8F5EF",
                  borderColor: "#c2ddd4",
                }}
              >
                <p
                  className="text-2xl tracking-[0.3em]"
                  style={{
                    fontWeight: 700,
                    fontFamily: "monospace",
                    color: "#1B7A5A",
                  }}
                >
                  ANT11A-2026
                </p>
              </div>
            </div>

            <button
              onClick={() => setShowInviteModal(false)}
              className="w-full py-2 rounded-lg text-sm text-white transition-opacity hover:opacity-90"
              style={{ background: "#1B7A5A" }}
            >
              Done
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

/* ── Timeline Tab ──────────────────────────────────────── */
function TimelineTab() {
  const { role } = useAuth();
  interface MaterialItem {
    id: string;
    name: string;
    size?: string;
    isLocked?: boolean;
  }
  interface QuizItem {
    id: string;
    title: string;
    questionsCount: number;
  }
  interface SessionItem {
    id: string;
    sessionLabel: string;
    materials: MaterialItem[];
    quizzes: QuizItem[];
    assignmentId: string;
  }
  interface WeekNode {
    id: string;
    weekNumber: number;
    isCompleted?: boolean;
    sessions: SessionItem[];
  }
  interface TodoItem {
    id: string;
    title: string;
    dueDate: string;
    questionsCount: number;
  }
  const [isEditing, setIsEditing] = useState(false);
  const [activeHomeworkId, setActiveHomeworkId] = useState<
    string | null
  >(null);
  const [activeTest, setActiveTest] = useState<string | null>(
    null,
  );

  // --- LOGIC ĐÓNG MỞ CỦA BẠN ---
  const currentWeek = 1; // Giả sử tuần 1 đang là hiện tại
  // Mặc định state sẽ lưu tuần đang mở là currentWeek
  const [expandedWeek, setExpandedWeek] = useState<
    number | null
  >(currentWeek);

  // 2. Mock Data
  const [roadmapData] = useState<WeekNode[]>([
    {
      id: "w1",
      weekNumber: 1,
      isCompleted: false,
      sessions: [
        {
          id: "s1.1",
          sessionLabel: "Session 1.1: Foundations of Rhetoric",
          materials: [
            {
              id: "m1",
              name: "Rhetoric_Primer.pdf",
              size: "1.2 MB",
              isLocked: false,
            },
          ],
          quizzes: [
            {
              id: "q1",
              title: "Diagnostic Quiz",
              questionsCount: 20,
            },
          ],
          assignmentId: "hw1_empty",
        },
        {
          id: "s1.2",
          sessionLabel: "Session 1.2: Structure & Logic",
          materials: [
            {
              id: "m2",
              name: "Logic_Basics.docx",
              size: "500 KB",
              isLocked: false,
            },
          ],
          quizzes: [],
          assignmentId: "hw2_empty",
        },
      ],
    },
    {
      id: "w2",
      weekNumber: 2,
      isCompleted: false,
      sessions: [
        {
          id: "s2.1",
          sessionLabel: "Session 2.1: Advanced Argumentation",
          materials: [
            {
              id: "m3",
              name: "Argument_Structures.pdf",
              isLocked: true,
            },
          ],
          quizzes: [],
          assignmentId: "hw3_empty",
        },
      ],
    },
  ]);

  const [todoList] = useState<TodoItem[]>([
    {
      id: "t1",
      title: "SAT Practice Test #3",
      dueDate: "Oct 20",
      questionsCount: 54,
    },
  ]);

  let breadcrumbContext = "";
  if (activeHomeworkId) {
    roadmapData.forEach((week) => {
      week.sessions.forEach((session) => {
        if (session.assignmentId === activeHomeworkId) {
          // Lấy text trước dấu ':' (Ví dụ từ "Session 1.1: ABC" -> "Session 1.1")
          const shortSessionName =
            session.sessionLabel.split(":")[0];
          breadcrumbContext = `Week ${week.weekNumber} ${shortSessionName}`;
        }
      });
    });
  }

  return (
    <div className="p-8 bg-background w-full font-sans">
      {role === "teacher" && (
        <div className="max-w-[1200px] mx-auto mb-6 flex items-center gap-2 text-[13px] font-medium -mt-4">
          <button
            onClick={() => setActiveHomeworkId(null)}
            className={`flex items-center gap-1 transition-colors ${
              activeHomeworkId
                ? "text-muted-foreground hover:text-[#1B7A5A]"
                : "text-[#1B7A5A]" // Nếu đang ở trang chủ Progress thì text màu xanh
            }`}
          >
            <span>Classroom</span>
            <ChevronRight size={14} />
            <span>Progress</span>
          </button>

          {activeHomeworkId && (
            <>
              <ChevronRight
                size={14}
                className="text-muted-foreground"
              />
              <button
                onClick={() => setActiveTest(null)}
                className={`transition-colors ${!activeTest ? "text-[#1B7A5A] font-bold" : "text-slate-500 hover:text-[#1B7A5A]"}`}
              >
                Homework ({breadcrumbContext})
              </button>
            </>
          )}

          {activeTest && (
            <>
              <ChevronRight
                size={14}
                className="text-slate-400"
              />
              <span className="text-[#1B7A5A] font-bold">
                Test Performance: ({activeTest})
              </span>
            </>
          )}
        </div>
      )}

      {activeHomeworkId || activeTest ? (
        activeTest ? (
          <TestPerformanceDashboard />
        ) : role === "teacher" ? (
          <AssignmentDetailTeacherView
            onTestClick={(testName) => setActiveTest(testName)}
          />
        ) : (
          <AssignmentDetailStudentView
            onBack={() => {
              setActiveHomeworkId(null);
              setActiveTest(null);
            }}
          />
        )
      ) : (
        <div className="max-w-[1200px] mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* ── CỘT TRÁI: ROADMAP ── */}
          <div className="lg:col-span-8 bg-card border border-border/60 rounded-2xl p-6 shadow-sm">
            <div className="flex items-center justify-between border-b border-border/60 pb-4 mb-6">
              <h2 className="text-lg font-bold text-foreground">
                Curriculum Roadmap
              </h2>
              {role === "teacher" && (
                <button
                  onClick={() => setIsEditing(!isEditing)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-semibold transition-all shadow-sm ${
                    isEditing
                      ? "bg-[#1B7A5A] text-white border-[#1B7A5A]"
                      : "bg-card text-muted-foreground hover:bg-muted"
                  }`}
                >
                  {isEditing ? (
                    <>
                      <Check size={13} /> Save Curriculum
                    </>
                  ) : (
                    <>
                      <Edit3 size={13} /> Edit Curriculum
                    </>
                  )}
                </button>
              )}
            </div>

            <div className="relative pl-6 flex flex-col gap-6">
              {/* Thanh dọc nối Timeline */}
              <div className="absolute left-[7px] top-4 bottom-4 w-px bg-border/80" />

              {roadmapData.map((week) => {
                const isCurrent =
                  week.weekNumber === currentWeek;
                const isExpanded =
                  expandedWeek === week.weekNumber;

                // Tính toán các thông số để hiển thị tóm tắt khi Box bị đóng
                const totalSessions = week.sessions.length;
                const totalMaterials = week.sessions.reduce(
                  (acc, s) => acc + s.materials.length,
                  0,
                );
                const totalQuizzes = week.sessions.reduce(
                  (acc, s) => acc + s.quizzes.length,
                  0,
                );

                return (
                  <div key={week.id} className="relative group">
                    {/* Chấm tròn Timeline theo style code cũ của bạn */}
                    <div
                      className="absolute left-[-23px] top-3 z-10 w-4 h-4 rounded-full border-2 flex items-center justify-center bg-background"
                      style={{
                        borderColor: week.isCompleted
                          ? "#1B7A5A"
                          : isCurrent
                            ? "#1B7A5A"
                            : "#E2EDE9",
                      }}
                    >
                      {(week.isCompleted || isCurrent) && (
                        <div
                          className="w-1.5 h-1.5 rounded-full"
                          style={{ background: "#1B7A5A" }}
                        />
                      )}
                    </div>

                    {/* ── BOX WEEK CÓ THỂ ĐÓNG/MỞ ── */}
                    <div
                      className={`bg-card border rounded-xl overflow-hidden transition-all ${isCurrent ? "shadow-sm" : ""}`}
                      style={{
                        borderColor: isCurrent
                          ? "rgba(27,122,90,0.4)"
                          : "#E2EDE9",
                      }}
                    >
                      {/* Header: Click để toggle */}
                      <div
                        onClick={() =>
                          setExpandedWeek(
                            isExpanded ? null : week.weekNumber,
                          )
                        }
                        className="w-full flex items-center justify-between px-4 py-3 hover:bg-muted/30 transition-colors cursor-pointer"
                      >
                        <div className="flex items-center gap-3">
                          <h3 className="text-sm font-bold uppercase tracking-wider text-[#1B7A5A] flex items-center gap-2">
                            WEEK {week.weekNumber}
                            {isCurrent && (
                              <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#E8F5EF] text-[#1B7A5A] lowercase normal-case tracking-normal font-semibold">
                                Current
                              </span>
                            )}
                          </h3>

                          {/* Hiển thị tóm tắt khi bị đóng lại */}
                          {!isExpanded && (
                            <div className="hidden sm:flex items-center gap-3 text-xs text-muted-foreground ml-2 border-l border-border pl-3">
                              <span className="flex items-center gap-1">
                                <BookOpen size={11} />{" "}
                                {totalSessions} session
                                {totalSessions > 1 ? "s" : ""}
                              </span>
                              <span className="flex items-center gap-1">
                                <FileText size={11} />{" "}
                                {totalMaterials} doc
                                {totalMaterials > 1 ? "s" : ""}
                              </span>
                              <span className="flex items-center gap-1">
                                <FileQuestion size={11} />{" "}
                                {totalQuizzes} quiz
                                {totalQuizzes > 1 ? "zes" : ""}
                              </span>
                            </div>
                          )}
                        </div>

                        <div className="flex items-center gap-3">
                          {isEditing && (
                            <div
                              className="flex items-center gap-1.5 transition-opacity mr-2"
                              onClick={(e) =>
                                e.stopPropagation()
                              } // Chặn sự kiện click mở box khi bấm nút sửa/xóa
                            >
                              <button className="p-1 text-muted-foreground hover:text-[#1B7A5A] rounded hover:bg-muted transition-colors">
                                <Plus size={14} />
                              </button>
                              <button className="p-1 text-muted-foreground hover:text-rose-600 rounded hover:bg-muted transition-colors">
                                <Trash2 size={14} />
                              </button>
                            </div>
                          )}
                          <div className="text-muted-foreground">
                            {isExpanded ? (
                              <ChevronDown size={16} />
                            ) : (
                              <ChevronRight size={16} />
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Nội dung chi tiết các Session (Chỉ render khi isExpanded = true) */}
                      {isExpanded && (
                        <div className="px-4 pb-5 pt-2 border-t border-border/50 flex flex-col gap-6">
                          {week.sessions.map((session) => (
                            <div
                              key={session.id}
                              className="flex flex-col gap-3"
                            >
                              <p className="text-sm font-bold text-foreground/90 border-l-2 border-[#1B7A5A] pl-2">
                                {session.sessionLabel}
                              </p>

                              <div className="flex flex-col gap-2 max-w-[540px] pl-2.5">
                                {session.materials.map(
                                  (material) => (
                                    <div
                                      key={material.id}
                                      className={`flex items-center justify-between border rounded-xl p-3 text-xs shadow-sm transition-all ${material.isLocked ? "bg-muted/40 border-border/40 opacity-70" : "bg-card border-border hover:shadow-md"}`}
                                    >
                                      <div className="flex items-center gap-2.5 min-w-0">
                                        <FileText
                                          size={16}
                                          className={
                                            material.isLocked
                                              ? "text-muted-foreground/60"
                                              : "text-rose-500"
                                          }
                                        />
                                        <div className="truncate">
                                          <p
                                            className={`font-medium truncate ${material.isLocked ? "text-muted-foreground/80 italic" : "text-foreground"}`}
                                          >
                                            {material.name}
                                          </p>
                                          {material.size && (
                                            <span className="text-[10px] text-muted-foreground">
                                              {material.size}
                                            </span>
                                          )}
                                          {material.isLocked && (
                                            <span className="text-[10px] text-muted-foreground flex items-center gap-0.5 mt-0.5">
                                              <LockIcon
                                                size={10}
                                              />{" "}
                                              Locked
                                            </span>
                                          )}
                                        </div>
                                      </div>
                                      <div className="flex items-center gap-1 shrink-0 ml-2">
                                        {!material.isLocked && (
                                          <button className="p-1.5 text-muted-foreground hover:text-foreground rounded-lg hover:bg-muted transition-colors">
                                            <Download
                                              size={13}
                                            />
                                          </button>
                                        )}
                                        {isEditing && (
                                          <button className="p-1.5 text-muted-foreground hover:text-rose-600 rounded-lg hover:bg-muted transition-colors">
                                            <Trash2 size={13} />
                                          </button>
                                        )}
                                      </div>
                                    </div>
                                  ),
                                )}

                                {session.quizzes.map((quiz) => (
                                  <div
                                    key={quiz.id}
                                    className="flex items-center justify-between border border-blue-500/20 bg-blue-50/50 rounded-xl p-3 text-xs shadow-sm transition-all hover:shadow-md hover:border-blue-500/40 cursor-pointer"
                                  >
                                    <div className="flex items-center gap-2.5 min-w-0">
                                      <div className="w-6 h-6 rounded bg-blue-100 flex items-center justify-center shrink-0">
                                        <FileQuestion
                                          size={13}
                                          className="text-blue-600"
                                        />
                                      </div>
                                      <div className="truncate">
                                        <p className="font-medium text-blue-950 truncate">
                                          {quiz.title}
                                        </p>
                                        <span className="text-[10px] text-blue-600/80">
                                          {quiz.questionsCount}{" "}
                                          Questions
                                        </span>
                                      </div>
                                    </div>
                                    <div className="flex items-center gap-1 shrink-0 ml-2">
                                      {isEditing && (
                                        <button className="p-1.5 text-muted-foreground hover:text-rose-600 rounded-lg hover:bg-white/50 transition-colors">
                                          <Trash2 size={13} />
                                        </button>
                                      )}
                                    </div>
                                  </div>
                                ))}

                                {isEditing && (
                                  <div className="flex gap-2 mt-1">
                                    <button className="flex-1 flex items-center justify-center gap-1.5 border-2 border-dashed border-border hover:border-[#1B7A5A]/40 hover:bg-muted/30 transition-all rounded-xl py-2 py-2 text-xs font-semibold text-muted-foreground hover:text-[#1B7A5A]">
                                      <Plus size={13} /> Add
                                      Material
                                    </button>
                                    <button className="flex-1 flex items-center justify-center gap-1.5 border-2 border-dashed border-border hover:border-blue-500/40 hover:bg-blue-50/50 transition-all rounded-xl py-2 py-2 text-xs font-semibold text-muted-foreground hover:text-blue-600">
                                      <Plus size={13} /> Add
                                      Quiz
                                    </button>
                                  </div>
                                )}

                                <div className="border border-border/80 bg-card rounded-xl p-3 max-w-[540px] shadow-sm mt-2">
                                  <div className="flex items-center justify-between mb-2">
                                    <span className="text-[10px] font-bold tracking-wider text-[#1B7A5A] uppercase">
                                      Session Assignment
                                    </span>
                                    {isEditing && (
                                      <button className="text-[11px] font-medium text-muted-foreground hover:text-[#1B7A5A] flex items-center gap-1">
                                        <Settings size={11} />{" "}
                                        Manage
                                      </button>
                                    )}
                                  </div>
                                  <div
                                    onClick={() =>
                                      setActiveHomeworkId(
                                        session.assignmentId,
                                      )
                                    }
                                    className="flex items-center justify-between border border-dashed border-[#1B7A5A]/40 bg-[#1B7A5A]/5 rounded-lg p-3 cursor-pointer hover:bg-[#1B7A5A]/10 transition-all group"
                                  >
                                    <div className="flex items-center gap-3 min-w-0">
                                      <div className="w-8 h-8 rounded-lg bg-background border border-[#1B7A5A]/20 flex items-center justify-center text-[#1B7A5A] shrink-0">
                                        <ClipboardList
                                          size={15}
                                        />
                                      </div>
                                      <div className="truncate">
                                        <h4 className="text-[13px] font-bold text-[#1B7A5A] truncate">
                                          Homework
                                        </h4>
                                        <p className="text-[11px] text-[#1B7A5A]/70 mt-0.5 italic">
                                          Currently empty •
                                          Click to open
                                        </p>
                                      </div>
                                    </div>
                                    <ChevronRight
                                      size={16}
                                      className="text-[#1B7A5A]/50 group-hover:text-[#1B7A5A] shrink-0 ml-2 transition-colors"
                                    />
                                  </div>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}

              {isEditing && (
                <div className="pt-2 pl-4">
                  <button className="flex items-center gap-2 bg-[#024D35] hover:bg-[#013826] text-white text-xs font-semibold px-4 py-2 rounded-lg transition-all shadow-sm">
                    <Plus size={14} /> Add New Week
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* ── CỘT PHẢI: TO-DO SIDEBAR (Giữ nguyên) ── */}
          <div className="lg:col-span-4 bg-card border border-border/60 rounded-2xl p-5 shadow-sm self-start">
            <h3 className="text-sm font-bold text-foreground mb-4">
              To-Do
            </h3>
            <div className="flex flex-col gap-3">
              {todoList.map((todo) => (
                <div
                  key={todo.id}
                  className="border border-border rounded-xl p-4 flex flex-col gap-2 bg-card hover:shadow-sm transition-all"
                >
                  <h4 className="text-xs font-bold text-foreground leading-snug">
                    {todo.title}
                  </h4>
                  <div className="flex items-center justify-between text-[11px] text-muted-foreground font-medium mt-1">
                    <span className="flex items-center gap-1">
                      <Calendar
                        size={11}
                        className="text-muted-foreground/70"
                      />{" "}
                      Due: {todo.dueDate}
                    </span>
                    <span>{todo.questionsCount} Questions</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ── Assignment Dashboard ──────────────────────────────── */
function AssignmentDashboard({
  weekLabel,
  stats,
  onBack,
}: {
  weekLabel: string;
  stats: (typeof assignmentStats)[string];
  onBack: () => void;
}) {
  if (!stats) {
    return (
      <div className="p-8">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-sm mb-4 hover:underline"
          style={{ color: "#1B7A5A" }}
        >
          ← Back to Timeline
        </button>
        <p className="text-muted-foreground text-sm">
          No data available for this test yet.
        </p>
      </div>
    );
  }

  const completed = stats.students.filter(
    (s) => s.completed,
  ).length;
  const total = stats.students.length;

  return (
    <div className="p-8">
      <button
        onClick={onBack}
        className="flex items-center gap-1.5 text-sm mb-5 hover:underline"
        style={{ color: "#1B7A5A" }}
      >
        ← Back to Timeline: {weekLabel}
      </button>

      <div className="grid grid-cols-3 gap-4 mb-6">
        <StatCard
          label="Completion Rate"
          value={`${Math.round((completed / total) * 100)}%`}
          sub={`${completed}/${total} students`}
          color="#1B7A5A"
        />
        <StatCard
          label="Average Score"
          value={stats.avgScore.toString()}
          sub="out of 1600"
          color="#1B7A5A"
        />
        <StatCard
          label="Pending"
          value={`${total - completed}`}
          sub="students remaining"
          color="#b45309"
        />
      </div>

      <div className="bg-card border border-border rounded-xl p-4 mb-5">
        <div className="flex items-center justify-between text-xs text-muted-foreground mb-2">
          <span>Class completion</span>
          <span>{Math.round((completed / total) * 100)}%</span>
        </div>
        <div className="w-full h-2 bg-muted rounded-full">
          <div
            className="h-2 rounded-full transition-all"
            style={{
              width: `${(completed / total) * 100}%`,
              background: "#1B7A5A",
            }}
          />
        </div>
      </div>

      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border bg-muted/40">
              <th
                className="text-left px-5 py-3 text-xs text-muted-foreground"
                style={{ fontWeight: 500 }}
              >
                Student
              </th>
              <th
                className="text-left px-4 py-3 text-xs text-muted-foreground"
                style={{ fontWeight: 500 }}
              >
                Status
              </th>
              <th
                className="text-right px-4 py-3 text-xs text-muted-foreground"
                style={{ fontWeight: 500 }}
              >
                Score
              </th>
              <th
                className="text-right px-5 py-3 text-xs text-muted-foreground"
                style={{ fontWeight: 500 }}
              >
                Submitted
              </th>
            </tr>
          </thead>
          <tbody>
            {stats.students.map((s, i) => (
              <tr
                key={s.name}
                className={`hover:bg-muted/30 ${i !== stats.students.length - 1 ? "border-b border-border" : ""}`}
              >
                <td className="px-5 py-3">
                  <div className="flex items-center gap-2.5">
                    <div
                      className="w-7 h-7 rounded-full flex items-center justify-center text-xs text-white"
                      style={{
                        background: s.color,
                        fontWeight: 600,
                      }}
                    >
                      {s.initials}
                    </div>
                    <span>{s.name}</span>
                  </div>
                </td>
                <td className="px-4 py-3">
                  {s.completed ? (
                    <span
                      className="flex items-center gap-1 text-xs"
                      style={{ color: "#1B7A5A" }}
                    >
                      <CheckCircle2 size={12} /> Completed
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 text-xs text-amber-600">
                      <Clock size={12} /> Pending
                    </span>
                  )}
                </td>
                <td
                  className="px-4 py-3 text-right"
                  style={{
                    fontFamily: "monospace",
                    fontWeight: 500,
                  }}
                >
                  {s.score ?? "—"}
                </td>
                <td className="px-5 py-3 text-right text-muted-foreground text-xs">
                  {s.submittedAt ?? "—"}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function StatCard({
  label,
  value,
  sub,
  color,
}: {
  label: string;
  value: string;
  sub: string;
  color: string;
}) {
  return (
    <div className="bg-card border border-border rounded-xl p-4">
      <p className="text-xs text-muted-foreground mb-1">
        {label}
      </p>
      <p
        className="text-2xl"
        style={{
          fontWeight: 700,
          fontFamily: "monospace",
          color,
        }}
      >
        {value}
      </p>
      <p className="text-xs text-muted-foreground mt-0.5">
        {sub}
      </p>
    </div>
  );
}