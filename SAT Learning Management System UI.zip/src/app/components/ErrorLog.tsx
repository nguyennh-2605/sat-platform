import { useState, useRef, useEffect } from "react";
import antLogo from "../../imports/image.png";
import {
  Flag,
  Search,
  CheckCircle2,
  XCircle,
  Lightbulb,
  Send,
  Bot,
  User,
  Sparkles,
  X,
  PenTool,
  ChevronDown,
} from "lucide-react";
import { GlobalHeader } from "./GlobalHeader";

/* ── SAT section taxonomy ──────────────────────────────── */
const RW_SECTIONS = [
  "Information and Ideas",
  "Craft and Structure",
  "Expression of Ideas",
  "Standard English Conventions",
] as const;

const MATH_SECTIONS = [
  "Algebra",
  "Advanced Math",
  "Problem Solving & Data Analysis",
  "Geometry & Trigonometry",
] as const;

type RWSection = (typeof RW_SECTIONS)[number];
type MathSection = (typeof MATH_SECTIONS)[number];
type SATSection = RWSection | MathSection;

/* ── Error entry ───────────────────────────────────────── */
interface ErrorEntry {
  id: number;
  testTitle: string;
  questionNum: number;
  subject: "RW" | "Math";
  section: SATSection;
  difficulty: "Easy" | "Medium" | "Hard";
  question: string;
  choices: { label: string; text: string }[];
  correctAnswer: string;
  studentAnswer: string;
  explanation: string;
  flagged: boolean;
  date: string;
}

const errorEntries: ErrorEntry[] = [
  {
    id: 1,
    testTitle: "Practice Test #8",
    questionNum: 14,
    subject: "Math",
    section: "Algebra",
    difficulty: "Hard",
    question:
      "If x² – 5x + 6 = 0, which of the following gives all values of x that satisfy the equation?",
    choices: [
      { label: "A", text: "x = 2 and x = 3" },
      { label: "B", text: "x = –2 and x = –3" },
      { label: "C", text: "x = 1 and x = 6" },
      { label: "D", text: "x = –1 and x = 6" },
    ],
    correctAnswer: "A",
    studentAnswer: "C",
    explanation:
      "Factor the quadratic: x² – 5x + 6 = (x – 2)(x – 3) = 0, so x = 2 or x = 3. Choice C gives x = 1 and 6, which don't satisfy the equation.",
    flagged: true,
    date: "Apr 27",
  },
  {
    id: 2,
    testTitle: "Math — Algebra Focus",
    questionNum: 7,
    subject: "Math",
    section: "Algebra",
    difficulty: "Medium",
    question:
      "A system of two linear equations has the same solution as y = 2x + 3 and y = –x + 9. What is the value of x?",
    choices: [
      { label: "A", text: "x = 1" },
      { label: "B", text: "x = 2" },
      { label: "C", text: "x = 3" },
      { label: "D", text: "x = 4" },
    ],
    correctAnswer: "B",
    studentAnswer: "C",
    explanation:
      "Set the two equations equal: 2x + 3 = –x + 9 → 3x = 6 → x = 2.",
    flagged: false,
    date: "Mar 16",
  },
  {
    id: 3,
    testTitle: "RW — Reading Sprint",
    questionNum: 3,
    subject: "RW",
    section: "Craft and Structure",
    difficulty: "Hard",
    question:
      "The author's use of the phrase 'silent cartographer' most strongly suggests that the subject is someone who",
    choices: [
      {
        label: "A",
        text: "draws maps without formal training",
      },
      {
        label: "B",
        text: "maps social structures through observation rather than speech",
      },
      {
        label: "C",
        text: "refuses to document the territories they explore",
      },
      {
        label: "D",
        text: "communicates cartographic findings non-verbally",
      },
    ],
    correctAnswer: "B",
    studentAnswer: "D",
    explanation:
      "'Silent cartographer' is a metaphor — the subject studies social groups by observation, not literal map-drawing or non-verbal communication.",
    flagged: true,
    date: "Mar 23",
  },
  {
    id: 4,
    testTitle: "RW — Grammar",
    questionNum: 28,
    subject: "RW",
    section: "Standard English Conventions",
    difficulty: "Medium",
    question:
      "Which choice most effectively combines the following sentences? 'The experiment was a success. The results surprised everyone on the team.'",
    choices: [
      {
        label: "A",
        text: "The experiment was a success, the results surprised everyone on the team.",
      },
      {
        label: "B",
        text: "The experiment was a success; however, the results surprised everyone on the team.",
      },
      {
        label: "C",
        text: "The experiment was a success, and the results surprised everyone on the team.",
      },
      {
        label: "D",
        text: "The experiment was a success: the results surprised everyone on the team.",
      },
    ],
    correctAnswer: "C",
    studentAnswer: "A",
    explanation:
      "Choice A is a comma splice. Use ', and' (coordinating conjunction) to correctly join two independent clauses.",
    flagged: false,
    date: "Mar 30",
  },
  {
    id: 5,
    testTitle: "Practice Test #7",
    questionNum: 52,
    subject: "Math",
    section: "Problem Solving & Data Analysis",
    difficulty: "Easy",
    question:
      "If 3/4 of a number is 24, what is 5/8 of the same number?",
    choices: [
      { label: "A", text: "18" },
      { label: "B", text: "20" },
      { label: "C", text: "22" },
      { label: "D", text: "25" },
    ],
    correctAnswer: "B",
    studentAnswer: "A",
    explanation:
      "(3/4)n = 24 → n = 32. Then (5/8) × 32 = 20. Choice A (18) = (9/16) × 32, a common calculation error.",
    flagged: false,
    date: "Apr 5",
  },
  {
    id: 6,
    testTitle: "RW — Reading Sprint",
    questionNum: 9,
    subject: "RW",
    section: "Information and Ideas",
    difficulty: "Medium",
    question:
      "According to the passage, which factor most directly contributed to the researcher's shift in methodology?",
    choices: [
      { label: "A", text: "Budget constraints" },
      { label: "B", text: "Unexpected sample results" },
      { label: "C", text: "Peer feedback during review" },
      { label: "D", text: "Changes in institutional policy" },
    ],
    correctAnswer: "C",
    studentAnswer: "B",
    explanation:
      "Paragraph 3 explicitly names peer review feedback as the catalyst. Answer B is tempting because sample anomalies are mentioned, but they are described as pre-existing conditions, not triggers.",
    flagged: false,
    date: "Apr 10",
  },
];

/* ── Chat ──────────────────────────────────────────────── */
interface ChatMsg {
  id: number;
  role: "user" | "ai";
  text: string;
}

const initialMessages: ChatMsg[] = [
  {
    id: 1,
    role: "ai",
    text: "Xin chào! I'm your ANT Academy AI tutor. Select a question from your error log and I'll help you understand it step by step. 📚",
  },
];

const aiResponses: Record<number, string[]> = {
  1: [
    "Let's tackle x² – 5x + 6 = 0.\n\nFactor: (x – 2)(x – 3) = 0 → x = 2 or x = 3. ✅\n\nYou chose C (x = 1, 6). Verify: 1 – 5 + 6 = 2 ≠ 0, and 36 – 30 + 6 = 12 ≠ 0. Neither works!",
    "The trick: you need two numbers that multiply to +6 AND add to –5 (not +5). Those are –2 and –3, giving roots x = 2 and x = 3.",
  ],
  2: [
    "Set expressions equal: 2x + 3 = –x + 9 → 3x = 6 → x = 2. ✅\n\nCommon error: subtracting 3 only from one side to get 3x = 9, x = 3.",
  ],
  3: [
    "'Silent cartographer' is a metaphor. The subject isn't literally drawing maps — they're *mapping* (observing and recording) social structures without speaking.\n\nChoice D confuses 'silent' with non-verbal communication, missing the cartographer metaphor entirely.",
  ],
};

export function ErrorLog() {
  const [selected, setSelected] = useState<ErrorEntry | null>(
    errorEntries[0],
  );
  const [search, setSearch] = useState("");
  const [activeSection, setActiveSection] =
    useState<SATSection | null>(null);
  const [messages, setMessages] =
    useState<ChatMsg[]>(initialMessages);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);

  // States cho Draggable AI Chat Modal
  const [showAiChat, setShowAiChat] = useState(false);
  const [modalPos, setModalPos] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });

  const [isRWExpanded, setIsRWExpanded] = useState(false);
  const [isMathExpanded, setIsMathExpanded] = useState(false);

  // Kiểm tra xem nhóm nào đang có filter được chọn (để hiện dấu chấm xanh báo hiệu)
  const hasActiveRW =
    activeSection && RW_SECTIONS.includes(activeSection as any);
  const hasActiveMath =
    activeSection &&
    MATH_SECTIONS.includes(activeSection as any);

  // States cho lưu trữ phản hồi tự thân của học sinh theo câu hỏi
  const [reflections, setReflections] = useState<
    Record<number, { wrong: string; right: string }>
  >({});

  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  // Thiết lập vị trí mặc định cho modal ở góc phải màn hình sau khi mount
  useEffect(() => {
    setModalPos({ x: window.innerWidth - 320, y: 160 });
  }, []);

  const filtered = errorEntries.filter((e) => {
    const matchSearch =
      e.question.toLowerCase().includes(search.toLowerCase()) ||
      e.section.toLowerCase().includes(search.toLowerCase()) ||
      e.testTitle.toLowerCase().includes(search.toLowerCase());
    const matchSection =
      activeSection === null || e.section === activeSection;
    return matchSearch && matchSection;
  });

  const handleSelectEntry = (entry: ErrorEntry) => {
    setSelected(entry);
    setMessages([
      ...initialMessages,
      {
        id: 2,
        role: "ai",
        text: `Loaded Q${entry.questionNum} from "${entry.testTitle}".\nSection: **${entry.section}** · ${entry.difficulty}\n\nWhat would you like me to explain? I can walk through the solution, explain why your answer was wrong, or give you a practice variant.`,
      },
    ]);
  };

  const sendMessage = () => {
    if (!input.trim()) return;
    const userMsg: ChatMsg = {
      id: messages.length + 1,
      role: "user",
      text: input,
    };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setIsTyping(true);
    const responses = selected
      ? (aiResponses[selected.id] ?? [])
      : [];
    const idx =
      messages.filter((m) => m.role === "ai").length - 1;
    const reply =
      responses[idx % responses.length] ??
      "Great question! Try re-reading the explanation above. Want me to generate a similar practice problem?";
    setTimeout(() => {
      setIsTyping(false);
      setMessages((prev) => [
        ...prev,
        { id: prev.length + 1, role: "ai", text: reply },
      ]);
    }, 1200);
  };

  // Logic Xử lý Kéo rê (Draggable) cho Modal AI Chat
  const handleMouseDown = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest(".close-btn")) return;
    setIsDragging(true);
    setDragStart({
      x: e.clientX - modalPos.x,
      y: e.clientY - modalPos.y,
    });
  };

  useEffect(() => {
    if (!isDragging) return;
    const handleMouseMove = (e: MouseEvent) => {
      setModalPos({
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y,
      });
    };
    const handleMouseUp = () => {
      setIsDragging(false);
    };

    window.addEventListener("mousemove", handleMouseMove);
    window.addEventListener("mouseup", handleMouseUp);
    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("mouseup", handleMouseUp);
    };
  }, [isDragging, dragStart]);

  const handleReflectionChange = (
    field: "wrong" | "right",
    value: string,
  ) => {
    if (!selected) return;
    setReflections((prev) => ({
      ...prev,
      [selected.id]: {
        ...prev[selected.id],
        [field]: value,
      },
    }));
  };

  const currentReflection = selected
    ? reflections[selected.id] || { wrong: "", right: "" }
    : { wrong: "", right: "" };

  const subjectChipStyle = (subj: "RW" | "Math") =>
    subj === "RW"
      ? {
          background: "#E8F5EF",
          color: "#1B7A5A",
          border: "1px solid #c2ddd4",
        }
      : {
          background: "#FEF9E7",
          color: "#92640a",
          border: "1px solid #f0d070",
        };

  const diffStyle: Record<string, React.CSSProperties> = {
    Easy: {
      background: "#f0fdf4",
      color: "#166534",
      border: "1px solid #bbf7d0",
    },
    Medium: {
      background: "#fffbeb",
      color: "#92400e",
      border: "1px solid #fde68a",
    },
    Hard: {
      background: "#fff1f2",
      color: "#9f1239",
      border: "1px solid #fecdd3",
    },
  };

  return (
    <div className="flex flex-col h-full bg-background overflow-hidden relative">
      <GlobalHeader
        title="Error Log"
        subtitle="Track and review your mistakes"
      />

      <div className="flex flex-1 overflow-hidden">
        {/* ── LEFT SECTION: Entry List & Compact Filters ─────────────────── */}
        <div className="w-[280px] shrink-0 border-r border-border bg-card flex flex-col">
          <div className="px-3 pt-4 pb-2 border-b border-border">
            {/* Search */}
            <div className="relative mb-2">
              <Search
                size={13}
                className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground"
              />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search errors…"
                className="w-full pl-7 pr-3 py-1 rounded-lg border border-border bg-input-background text-xs placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>

            {/* Compact Section filter pills */}
            {/* Compact Section filter (Accordion) */}
            <div className="flex flex-col gap-2 mt-2.5">
              {/* RW Group */}
              <div>
                <button
                  onClick={() => setIsRWExpanded(!isRWExpanded)}
                  className="w-full flex items-center justify-between text-[10px] uppercase tracking-wider text-muted-foreground font-bold hover:text-[#1B7A5A] transition-colors"
                >
                  <span className="flex items-center gap-1.5">
                    Reading & Writing
                    {/* Chấm xanh báo hiệu đang có filter được chọn ở nhóm này */}
                    {hasActiveRW && (
                      <span className="w-1.5 h-1.5 rounded-full bg-[#1B7A5A]"></span>
                    )}
                  </span>
                  <ChevronDown
                    size={12}
                    className={`transition-transform duration-200 ${isRWExpanded ? "rotate-180" : ""}`}
                  />
                </button>

                {isRWExpanded && (
                  <div className="flex flex-wrap gap-1 mt-2 animate-in slide-in-from-top-1 fade-in duration-200">
                    {RW_SECTIONS.map((s) => (
                      <SectionPill
                        key={s}
                        label={s}
                        active={activeSection === s}
                        onClick={() =>
                          setActiveSection(
                            activeSection === s ? null : s,
                          )
                        }
                      />
                    ))}
                  </div>
                )}
              </div>

              {/* Math Group */}
              <div>
                <button
                  onClick={() =>
                    setIsMathExpanded(!isMathExpanded)
                  }
                  className="w-full flex items-center justify-between text-[10px] uppercase tracking-wider text-muted-foreground font-bold hover:text-[#1B7A5A] transition-colors"
                >
                  <span className="flex items-center gap-1.5">
                    Math
                    {hasActiveMath && (
                      <span className="w-1.5 h-1.5 rounded-full bg-[#1B7A5A]"></span>
                    )}
                  </span>
                  <ChevronDown
                    size={12}
                    className={`transition-transform duration-200 ${isMathExpanded ? "rotate-180" : ""}`}
                  />
                </button>

                {isMathExpanded && (
                  <div className="flex flex-wrap gap-1 mt-2 animate-in slide-in-from-top-1 fade-in duration-200">
                    {MATH_SECTIONS.map((s) => (
                      <SectionPill
                        key={s}
                        label={s}
                        active={activeSection === s}
                        onClick={() =>
                          setActiveSection(
                            activeSection === s ? null : s,
                          )
                        }
                      />
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Entry list */}
          <div className="flex-1 overflow-y-auto">
            {filtered.map((entry) => (
              <button
                key={entry.id}
                onClick={() => handleSelectEntry(entry)}
                className={`w-full text-left px-3 py-2.5 border-b border-border hover:bg-muted/40 transition-colors ${
                  selected?.id === entry.id
                    ? "bg-[#E8F5EF]/60 border-l-2 border-l-[#1B7A5A]"
                    : ""
                }`}
              >
                <div className="flex items-center justify-between mt-1">
                  <div className="flex flex-wrap gap-1 mb-1">
                    <span
                      className="px-1 py-0.5 rounded-full"
                      style={{
                        ...subjectChipStyle(entry.subject),
                        fontSize: "9px",
                        fontWeight: 600,
                      }}
                    >
                      {entry.subject}
                    </span>
                    <span
                      className="px-1 py-0.5 rounded-full border truncate max-w-[120px]"
                      style={{
                        background: "#f9fafb",
                        color: "#4b5563",
                        borderColor: "#e5e7eb",
                        fontSize: "9px",
                      }}
                    >
                      {entry.section}
                    </span>
                  </div>
                  <div className="flex items-center gap-1">
                    {entry.flagged && (
                      <Flag
                        size={9}
                        style={{
                          fill: "#dc2626",
                          color: "#dc2626",
                        }}
                      />
                    )}
                    <span className="text-[10px] text-muted-foreground">
                      {entry.date}
                    </span>
                  </div>
                </div>
                <p className="text-xs text-foreground leading-snug line-clamp-2 font-medium">
                  Q{entry.questionNum}: {entry.testTitle}
                </p>
              </button>
            ))}
            {filtered.length === 0 && (
              <div className="p-4 text-center text-xs text-muted-foreground">
                No errors match.
              </div>
            )}
          </div>
        </div>

        {/* ── CENTER SECTION: Question Detail & "Ask AI" Trigger ────────── */}
        <div className="flex-1 flex flex-col overflow-hidden bg-background">
          {selected ? (
            <div className="flex-1 overflow-y-auto p-6">
              {/* Header */}
              <div className="flex items-start justify-between mb-4">
                <div>
                  <div className="flex flex-wrap gap-1.5 mb-1.5">
                    <span
                      className="text-xs px-2 py-0.5 rounded-full"
                      style={{
                        ...subjectChipStyle(selected.subject),
                        fontWeight: 600,
                      }}
                    >
                      {selected.subject}
                    </span>
                    <span
                      className="text-xs px-2 py-0.5 rounded-full border"
                      style={{
                        background: "#f9fafb",
                        color: "#374151",
                        borderColor: "#d1d5db",
                      }}
                    >
                      {selected.section}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {selected.testTitle} · Q
                    {selected.questionNum} · {selected.date}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  {selected.flagged && (
                    <span
                      className="flex items-center gap-1 text-xs px-2 py-1 rounded-lg border"
                      style={{
                        background: "#fff1f2",
                        color: "#be123c",
                        borderColor: "#fecdd3",
                      }}
                    >
                      <Flag
                        size={11}
                        style={{ fill: "#be123c" }}
                      />{" "}
                      Flagged
                    </span>
                  )}
                  {/* Nút kích hoạt AI Chat Modal */}
                  <button
                    onClick={() => setShowAiChat(true)}
                    className="flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 bg-[#1B7A5A] hover:bg-[#0F4D38] text-white rounded-lg transition-colors shadow-sm"
                  >
                    <Sparkles size={13} /> Ask AI
                  </button>
                </div>
              </div>

              {/* Question */}
              <div className="bg-card border border-border rounded-xl p-5 mb-4 shadow-sm">
                <p className="text-sm text-foreground leading-relaxed">
                  {selected.question}
                </p>
                <div className="grid grid-cols-2 gap-2 mt-4">
                  {selected.choices.map((c) => {
                    const isCorrect =
                      c.label === selected.correctAnswer;
                    const isStudent =
                      c.label === selected.studentAnswer;
                    return (
                      <div
                        key={c.label}
                        className="flex items-start gap-2.5 px-3 py-2.5 rounded-lg border text-sm"
                        style={
                          isCorrect
                            ? {
                                background: "#f0fdf4",
                                borderColor: "#86efac",
                                color: "#166534",
                              }
                            : isStudent
                              ? {
                                  background: "#fff1f2",
                                  borderColor: "#fca5a5",
                                  color: "#9f1239",
                                }
                              : {
                                  background: "#f9fafb",
                                  borderColor: "#e5e7eb",
                                  color: "#6b7280",
                                }
                        }
                      >
                        <span
                          className="shrink-0"
                          style={{
                            fontWeight: 600,
                            fontFamily: "monospace",
                          }}
                        >
                          {c.label}.
                        </span>
                        <span className="leading-snug">
                          {c.text}
                        </span>
                        {isCorrect && (
                          <CheckCircle2
                            size={14}
                            className="ml-auto shrink-0 mt-0.5"
                            style={{ color: "#16a34a" }}
                          />
                        )}
                        {isStudent && !isCorrect && (
                          <XCircle
                            size={14}
                            className="ml-auto shrink-0 mt-0.5"
                            style={{ color: "#dc2626" }}
                          />
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Explanation */}
              <div
                className="rounded-xl p-4 border shadow-sm"
                style={{
                  background: "#E8F5EF",
                  borderColor: "#c2ddd4",
                }}
              >
                <p
                  className="text-xs mb-2 flex items-center gap-1.5"
                  style={{ fontWeight: 600, color: "#1B7A5A" }}
                >
                  <Lightbulb size={13} /> Explanation
                </p>
                <p className="text-sm text-foreground leading-relaxed">
                  {selected.explanation}
                </p>
              </div>
            </div>
          ) : (
            <div className="flex-1 flex items-center justify-center text-muted-foreground text-sm">
              Select an error from the list
            </div>
          )}
        </div>

        {/* ── RIGHT SECTION: Vertical Student Reflection Fields ─────────── */}
        <div className="w-80 shrink-0 border-l border-border bg-card flex flex-col p-5 overflow-y-auto">
          <div className="flex items-center gap-2 pb-4 mb-4 border-b border-border">
            <PenTool size={16} className="text-[#1B7A5A]" />
            <h3 className="text-sm font-bold text-foreground">
              Self-Reflection
            </h3>
          </div>

          {selected ? (
            <div className="flex-1 flex flex-col gap-5">
              {/* Vùng nhập liệu: Why choose wrong? */}
              <div className="flex-1 flex flex-col min-h-[160px]">
                <label className="text-xs font-bold text-red-600 mb-2 flex items-center gap-1.5 uppercase tracking-wider">
                  <XCircle size={14} /> Why choose wrong?
                </label>
                <textarea
                  value={currentReflection.wrong}
                  onChange={(e) =>
                    handleReflectionChange(
                      "wrong",
                      e.target.value,
                    )
                  }
                  placeholder="Analyze the misunderstanding, core gaps, or the exact trap you fell into in this question..."
                  className="w-full flex-1 p-3 text-xs rounded-xl border border-border bg-background shadow-sm resize-none focus:outline-none focus:ring-2 focus:ring-[#1B7A5A] leading-relaxed transition-all"
                />
              </div>

              {/* Vùng nhập liệu: Why answer right? */}
              <div className="flex-1 flex flex-col min-h-[160px]">
                <label className="text-xs font-bold text-emerald-700 mb-2 flex items-center gap-1.5 uppercase tracking-wider">
                  <CheckCircle2 size={14} /> Why answer right?
                </label>
                <textarea
                  value={currentReflection.right}
                  onChange={(e) =>
                    handleReflectionChange(
                      "right",
                      e.target.value,
                    )
                  }
                  placeholder="Clarify the logical steps required to eliminate wrong choices and confirm the precise solution..."
                  className="w-full flex-1 p-3 text-xs rounded-xl border border-border bg-background shadow-sm resize-none focus:outline-none focus:ring-2 focus:ring-[#1B7A5A] leading-relaxed transition-all"
                />
              </div>
            </div>
          ) : (
            <div className="text-xs text-muted-foreground text-center mt-10">
              Select a question to log reflection.
            </div>
          )}
        </div>
      </div>

      {/* ── DRAGGABLE AI CHAT MODAL ────────────────────────────────────── */}
      {showAiChat && (
        <div
          style={{
            position: "fixed",
            left: `${modalPos.x}px`,
            top: `${modalPos.y}px`,
            zIndex: 50,
          }}
          className="w-72 h-[450px] bg-card rounded-xl shadow-2xl border border-border flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150"
        >
          {/* Header kéo rê (Drag Handle) */}
          <div
            onMouseDown={handleMouseDown}
            className={`px-4 py-3 border-b border-border flex items-center gap-2.5 shrink-0 select-none ${
              isDragging ? "cursor-grabbing" : "cursor-grab"
            }`}
            style={{ background: "#0F4D38" }}
          >
            <div className="flex items-center gap-2">
              <div className="w-5 h-5 rounded-full bg-[#1B7A5A] flex items-center justify-center">
                <Bot size={11} className="text-white" />
              </div>
              <div>
                <p className="text-xs font-bold text-white leading-none">
                  AI Tutor
                </p>
                <p
                  className="text-[10px]"
                  style={{ color: "#6bbfa0" }}
                >
                  Online · GPT-4o
                </p>
              </div>
            </div>

            <div className="ml-auto flex items-center gap-1.5 close-btn">
              <Sparkles
                size={12}
                style={{ color: "#E8C040" }}
              />
              <button
                onClick={() => setShowAiChat(false)}
                className="p-1 rounded-md text-emerald-200/70 hover:text-white hover:bg-white/10 transition-colors"
              >
                <X size={14} />
              </button>
            </div>
          </div>

          {/* Nội dung tin nhắn */}
          <div className="flex-1 overflow-y-auto px-3 py-3 flex flex-col gap-2.5 bg-background/50">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-2 ${msg.role === "user" ? "flex-row-reverse" : ""}`}
              >
                <div
                  className="w-5 h-5 rounded-full flex items-center justify-center shrink-0 mt-0.5"
                  style={
                    msg.role === "ai"
                      ? { background: "#1B7A5A" }
                      : { background: "#EAF2EE" }
                  }
                >
                  {msg.role === "ai" ? (
                    <Bot size={10} className="text-white" />
                  ) : (
                    <User
                      size={10}
                      style={{ color: "#1B7A5A" }}
                    />
                  )}
                </div>
                <div
                  className="max-w-[85%] text-[11px] px-2.5 py-1.5 rounded-xl leading-relaxed whitespace-pre-line shadow-sm"
                  style={
                    msg.role === "ai"
                      ? {
                          background: "#EAF2EE",
                          color: "#1A1A1A",
                          borderRadius: "12px 12px 12px 2px",
                        }
                      : {
                          background: "#1B7A5A",
                          color: "#fff",
                          borderRadius: "12px 12px 2px 12px",
                        }
                  }
                >
                  {msg.text}
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="flex gap-2">
                <div
                  className="w-5 h-5 rounded-full flex items-center justify-center"
                  style={{ background: "#1B7A5A" }}
                >
                  <Bot size={10} className="text-white" />
                </div>
                <div
                  className="text-[11px] px-2.5 py-1.5 rounded-xl"
                  style={{
                    background: "#EAF2EE",
                    color: "#6B7280",
                  }}
                >
                  <span className="flex gap-1">
                    <span
                      className="animate-bounce"
                      style={{ animationDelay: "0ms" }}
                    >
                      ·
                    </span>
                    <span
                      className="animate-bounce"
                      style={{ animationDelay: "150ms" }}
                    >
                      ·
                    </span>
                    <span
                      className="animate-bounce"
                      style={{ animationDelay: "300ms" }}
                    >
                      ·
                    </span>
                  </span>
                </div>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>

          {/* Ô Nhập nội dung Chat */}
          <div className="px-3 py-2.5 border-t border-border bg-card shrink-0">
            <div
              className="flex items-center gap-2 rounded-xl px-2.5 py-1.5 border"
              style={{
                background: "#EAF2EE",
                borderColor: "#E2EDE9",
              }}
            >
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) =>
                  e.key === "Enter" && sendMessage()
                }
                placeholder="Ask about this question…"
                className="flex-1 bg-transparent text-[11px] text-foreground placeholder:text-muted-foreground focus:outline-none"
              />
              <button
                onClick={sendMessage}
                disabled={!input.trim()}
                className="p-1 rounded-lg text-white disabled:opacity-40 transition-opacity hover:opacity-80 shrink-0"
                style={{ background: "#1B7A5A" }}
              >
                <Send size={10} />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ── Compact Section filter pill ───────────────────────── */
function SectionPill({
  label,
  active,
  onClick,
}: {
  label: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="text-[10px] px-1.5 py-0.5 rounded-md border transition-all m-0.5"
      style={
        active
          ? {
              background: "#1B7A5A",
              color: "#fff",
              borderColor: "#1B7A5A",
              fontWeight: 600,
            }
          : {
              background: "#fff",
              color: "#1B7A5A",
              borderColor: "#1B7A5A",
              fontWeight: 400,
            }
      }
    >
      {label}
    </button>
  );
}