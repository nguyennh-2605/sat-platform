import React from "react";
import {
  Edit3,
  Calendar,
  Users,
  List,
  CheckCircle2,
  Search,
  Filter,
  Download,
  FileText,
  Check,
  MoreHorizontal,
  ChevronLeft,
  ChevronRight,
  AlertTriangle,
} from "lucide-react";

interface StudentRow {
  id: string;
  initials: string;
  name: string;
  avatarBg: string;
  progress: number;
  total: number;
  progressColor: string;
  draft: string | null;
  status: string;
  statusTime: string;
  statusTheme: string;
  StatusIcon: any;
}

const studentData: StudentRow[] = [
  {
    id: "1",
    initials: "EH",
    name: "Eleanor Higgins",
    avatarBg: "bg-emerald-100 text-emerald-700",
    progress: 5,
    total: 5,
    progressColor: "bg-[#1B7A5A]",
    draft: "EHiggins_FinalDraft.docx",
    status: "Completed",
    statusTime: "Oct 23, 2:14 PM",
    statusTheme:
      "bg-emerald-100 text-emerald-700 border-emerald-200",
    StatusIcon: Check,
  },
  {
    id: "2",
    initials: "MR",
    name: "Marcus Reed",
    avatarBg: "bg-amber-100 text-amber-700",
    progress: 3,
    total: 5,
    progressColor: "bg-amber-500",
    draft: "MReed_Outline_v2.pdf",
    status: "In Progress",
    statusTime: "Active today",
    statusTheme:
      "bg-muted text-muted-foreground border-border/50",
    StatusIcon: MoreHorizontal,
  },
  {
    id: "3",
    initials: "JC",
    name: "Julianne Chen",
    avatarBg: "bg-slate-100 text-slate-600",
    progress: 1,
    total: 5,
    progressColor: "bg-rose-500",
    draft: null,
    status: "Action Needed",
    statusTime: "Stagnant 4 days",
    statusTheme: "bg-rose-100 text-rose-700 border-rose-200",
    StatusIcon: AlertTriangle,
  },
  {
    id: "4",
    initials: "SP",
    name: "Samuel Patel",
    avatarBg: "bg-emerald-100 text-emerald-700",
    progress: 5,
    total: 5,
    progressColor: "bg-[#1B7A5A]",
    draft: "SPatel_Final.docx",
    status: "Completed",
    statusTime: "Oct 24, 9:02 AM",
    statusTheme:
      "bg-emerald-100 text-emerald-700 border-emerald-200",
    StatusIcon: Check,
  },
];

const testBankModules = [
  "Ethos, Pathos, Logos Mastery",
  "Identifying Fallacies Q-Set",
  "AP Historical Texts Analysis",
  "Synthesis Prompt Practice 1",
  "Synthesis Prompt Practice 2",
];

interface TeacherViewProps {
  onTestClick: (testName: string) => void;
}

export default function AssignmentDetailTeacherView({
  onTestClick,
}: TeacherViewProps) {
  return (
    <div className="w-full animate-in fade-in slide-in-from-bottom-2 duration-300">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">
          Rhetoric and Argumentation - Final Practice
        </h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* ── CỘT TRÁI (1/3) ── */}
        <div className="lg:col-span-4 flex flex-col gap-6">
          <div className="bg-white border border-border/60 rounded-2xl p-5 shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-md font-bold">
                Assignment Details
              </h2>
              <button className="text-[#1B7A5A] p-1 rounded-lg hover:bg-muted">
                <Edit3 size={16} />
              </button>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed mb-4">
              Students must complete the assigned reading,
              complete all 5 practice tests from the Rhetoric
              Test Bank, and upload their final synthesis essay
              draft.
            </p>
            <div className="flex flex-col gap-3 text-xs">
              <div className="flex items-center justify-between border-b pb-2 text-slate-500">
                <span className="flex items-center gap-1.5">
                  <Calendar size={14} /> Due Date
                </span>
                <span className="font-semibold text-foreground">
                  Oct 24, 11:59 PM
                </span>
              </div>
              <div className="flex items-center justify-between border-b pb-2 text-slate-500">
                <span className="flex items-center gap-1.5">
                  <Users size={14} /> Assignees
                </span>
                <span className="font-semibold text-foreground">
                  Section A (24)
                </span>
              </div>
              <div className="flex items-center justify-between text-slate-500">
                <span className="flex items-center gap-1.5">
                  <List size={14} /> Points
                </span>
                <span className="font-semibold text-foreground">
                  100 (Weighted 15%)
                </span>
              </div>
            </div>
          </div>

          <div className="bg-white border border-border/60 rounded-2xl p-5 shadow-sm">
            <div className="flex items-center gap-2 mb-4">
              <h2 className="text-md font-bold">
                Test Bank Modules
              </h2>
              <span className="text-[10px] px-1.5 py-0.5 bg-slate-100 text-slate-600 rounded">
                5 Required
              </span>
            </div>
            <div className="flex flex-col gap-3 text-xs text-slate-700">
              {testBankModules.map((mod, i) => (
                <div
                  key={i}
                  onClick={() => onTestClick(mod)}
                  className="flex items-center gap-2 pb-2 border-b border-border/40 last:border-0 last:pb-0 cursor-pointer hover:text-[#1B7A5A] transition-colors group"
                >
                  <CheckCircle2
                    size={15}
                    className="text-[#1B7A5A] shrink-0"
                  />
                  <span className="group-hover:font-medium">
                    {mod}
                  </span>
                  <ChevronRight
                    size={14}
                    className="ml-auto opacity-0 group-hover:opacity-100 text-[#1B7A5A] transition-opacity"
                  />
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* ── CỘT PHẢI (2/3) ── */}
        <div className="lg:col-span-8 bg-white border border-border/60 rounded-2xl flex flex-col shadow-sm overflow-hidden">
          <div className="p-5 border-b border-border/60 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-md font-bold">
                Student Progress
              </h2>
              <p className="text-xs text-slate-500">
                Showing 24 students in Section A
              </p>
            </div>
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search
                  size={14}
                  className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400"
                />
                <input
                  type="text"
                  placeholder="Find student..."
                  className="pl-8 pr-3 py-1.5 border border-border rounded-lg text-xs w-[160px] focus:outline-none focus:ring-1 focus:ring-[#1B7A5A]/30"
                />
              </div>
              <button className="p-1.5 border rounded-lg text-slate-600 hover:bg-slate-50">
                <Filter size={15} />
              </button>
              <button className="p-1.5 border rounded-lg text-slate-600 hover:bg-slate-50">
                <Download size={15} />
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50/50 border-b text-slate-500">
                <tr>
                  <th className="px-4 py-3">Student</th>
                  <th className="px-4 py-3">
                    Test Bank Progress
                  </th>
                  <th className="px-4 py-3">
                    Draft Submission
                  </th>
                  <th className="px-4 py-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {studentData.map((student) => (
                  <tr
                    key={student.id}
                    className="hover:bg-slate-50/50 transition-colors"
                  >
                    <td className="px-4 py-3 font-medium">
                      <div className="flex items-center gap-2">
                        <div
                          className={`w-7 h-7 rounded-full flex items-center justify-center text-[10px] font-bold ${student.avatarBg}`}
                        >
                          {student.initials}
                        </div>
                        {student.name}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-16 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                          <div
                            className={`h-full ${student.progressColor}`}
                            style={{
                              width: `${(student.progress / student.total) * 100}%`,
                            }}
                          />
                        </div>
                        {student.progress}/{student.total}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      {student.draft ? (
                        <span className="text-[#1B7A5A] flex items-center gap-1 cursor-pointer hover:underline">
                          <FileText size={12} /> {student.draft}
                        </span>
                      ) : (
                        <span className="text-slate-400 italic">
                          — None
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] border ${student.statusTheme}`}
                      >
                        <student.StatusIcon size={10} />{" "}
                        {student.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="p-3 border-t flex items-center justify-between text-xs text-slate-500 bg-slate-50/30">
            <span>Showing 1-4 of 24</span>
            <div className="flex items-center gap-1">
              <button className="p-1 border rounded hover:bg-slate-100 disabled:opacity-40">
                <ChevronLeft size={14} />
              </button>
              <button className="p-1 border rounded hover:bg-slate-100">
                <ChevronRight size={14} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}