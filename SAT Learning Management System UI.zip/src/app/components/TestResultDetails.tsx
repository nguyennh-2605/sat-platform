import React from "react";
import {
  ArrowLeft,
  Calendar,
  Clock,
  List,
  CheckCircle2,
  XCircle,
  Filter,
  Bookmark,
  ChevronLeft,
  ChevronRight,
  Eye,
} from "lucide-react";

// Mock data cho bảng câu hỏi
const questionsData = [
  {
    id: "Q1",
    status: "correct",
    correctAns: "B",
    userAns: "B",
    logged: false,
  },
  {
    id: "Q2",
    status: "incorrect",
    correctAns: "D",
    userAns: "A",
    logged: false,
  },
  {
    id: "Q3",
    status: "correct",
    correctAns: "C",
    userAns: "C",
    logged: false,
  },
  {
    id: "Q4",
    status: "incorrect",
    correctAns: "A",
    userAns: "C",
    logged: true,
  },
  {
    id: "Q5",
    status: "correct",
    correctAns: "A",
    userAns: "A",
    logged: false,
  },
  {
    id: "Q6",
    status: "correct",
    correctAns: "D",
    userAns: "D",
    logged: false,
  },
  {
    id: "Q7",
    status: "incorrect",
    correctAns: "B",
    userAns: "C",
    logged: false,
  },
];

interface TestResultDetailsProps {
  onBack: () => void;
}

export default function TestResultDetails({
  onBack,
}: TestResultDetailsProps) {
  return (
    <div className="w-full h-full min-h-screen bg-slate-50 font-sans p-6 md:p-8 overflow-y-auto">
      <div className="max-w-[1200px] mx-auto animate-in fade-in duration-300">
        {/* ── NÚT BACK ── */}
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-sm font-bold text-slate-500 hover:text-slate-800 mb-6 transition-colors"
        >
          <ArrowLeft size={16} /> Back to Analytics
        </button>

        {/* ── HEADER ── */}
        <div className="mb-8">
          <h1 className="text-2xl font-extrabold text-slate-800 mb-2">
            Test Result Details
          </h1>
          <p className="text-sm text-slate-500 font-medium">
            Review your performance and identify areas for
            improvement.
          </p>
        </div>

        {/* ── THÔNG TIN BÀI TEST & ACCURACY ── */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          {/* Test Info Card (Chiếm 2 phần) */}
          <div className="lg:col-span-2 bg-white border border-slate-200 rounded-xl shadow-sm p-6 flex flex-col">
            <div className="flex items-start justify-between mb-6">
              <h2 className="text-xl font-bold text-[#1B7A5A]">
                SAT Reading & Writing Practice Test #1
              </h2>
              <span className="px-3 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-md text-xs font-bold">
                Completed
              </span>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <div>
                <p className="text-xs text-slate-500 font-medium mb-1">
                  Subject
                </p>
                <p className="text-sm font-semibold text-slate-800">
                  Reading & Writing
                </p>
              </div>
              <div>
                <p className="text-xs text-slate-500 font-medium mb-1">
                  Date
                </p>
                <p className="text-sm font-semibold text-slate-800">
                  Oct 24, 2026
                </p>
              </div>
              <div>
                <p className="text-xs text-slate-500 font-medium mb-1">
                  Time Started
                </p>
                <p className="text-sm font-semibold text-slate-800">
                  10:45 AM
                </p>
              </div>
              <div>
                <p className="text-xs text-slate-500 font-medium mb-1">
                  Time Spent
                </p>
                <p className="text-sm font-semibold text-slate-800">
                  54m 12s
                </p>
              </div>
            </div>
          </div>

          {/* Accuracy Card (Chiếm 1 phần) */}
          <div className="lg:col-span-1 bg-[#0F4D38] border border-[#0F4D38] rounded-xl shadow-sm p-6 flex flex-col items-center justify-center text-white relative overflow-hidden">
            {/* Background decoration pattern mờ */}
            <div className="absolute -right-8 -top-8 opacity-10">
              <CheckCircle2 size={120} />
            </div>

            <p className="text-sm font-bold text-emerald-100/80 mb-2 uppercase tracking-wider relative z-10">
              Accuracy
            </p>
            <div className="text-5xl font-extrabold font-monospace mb-3 relative z-10">
              77.8%
            </div>
            <div className="px-3 py-1 bg-white/10 rounded-full text-xs font-semibold backdrop-blur-sm relative z-10">
              Top 15% of peers
            </div>
          </div>
        </div>

        {/* ── THỐNG KÊ CÂU HỎI (3 CARDS) ── */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white border border-slate-200 border-l-4 border-l-slate-400 rounded-xl shadow-sm p-5 flex items-center gap-4">
            <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center text-slate-500 shrink-0">
              <List size={20} />
            </div>
            <div>
              <p className="text-xs text-slate-500 font-bold uppercase tracking-wider mb-0.5">
                Total Questions
              </p>
              <p className="text-2xl font-extrabold text-slate-800">
                54
              </p>
            </div>
          </div>

          <div className="bg-white border border-slate-200 border-l-4 border-l-[#1B7A5A] rounded-xl shadow-sm p-5 flex items-center gap-4">
            <div className="w-12 h-12 bg-[#E8F5EF] rounded-full flex items-center justify-center text-[#1B7A5A] shrink-0">
              <CheckCircle2 size={20} />
            </div>
            <div>
              <p className="text-xs text-slate-500 font-bold uppercase tracking-wider mb-0.5">
                Correct
              </p>
              <p className="text-2xl font-extrabold text-slate-800">
                42
              </p>
            </div>
          </div>

          <div className="bg-white border border-slate-200 border-l-4 border-l-red-500 rounded-xl shadow-sm p-5 flex items-center gap-4">
            <div className="w-12 h-12 bg-red-50 rounded-full flex items-center justify-center text-red-500 shrink-0">
              <XCircle size={20} />
            </div>
            <div>
              <p className="text-xs text-slate-500 font-bold uppercase tracking-wider mb-0.5">
                Incorrect
              </p>
              <p className="text-2xl font-extrabold text-slate-800">
                12
              </p>
            </div>
          </div>
        </div>

        {/* ── BẢNG QUESTION REVIEW ── */}
        <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
          {/* Table Header */}
          <div className="px-6 py-5 border-b border-slate-200 flex items-center justify-between">
            <h3 className="font-bold text-slate-800 text-lg">
              Question Review
            </h3>
            <button className="flex items-center gap-2 px-3 py-1.5 text-sm font-semibold text-slate-600 bg-white border border-slate-300 rounded-md hover:bg-slate-50 transition-colors">
              <Filter size={16} /> Filter
            </button>
          </div>

          {/* Table Content */}
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="bg-slate-50 border-b border-slate-200 text-xs text-slate-500 uppercase font-bold tracking-wider">
                <tr>
                  <th className="px-6 py-4 w-24">Question</th>
                  <th className="px-6 py-4 text-center">
                    Status
                  </th>
                  <th className="px-6 py-4 text-center">
                    Correct Answer
                  </th>
                  <th className="px-6 py-4 text-center">
                    Your Answer
                  </th>
                  <th className="px-6 py-4 text-right">
                    Action
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {questionsData.map((q, index) => {
                  const isCorrect = q.status === "correct";

                  return (
                    <tr
                      key={index}
                      className="hover:bg-slate-50/50 transition-colors"
                    >
                      <td className="px-6 py-4 font-semibold text-slate-700">
                        {q.id}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex justify-center">
                          {isCorrect ? (
                            <CheckCircle2
                              size={20}
                              className="text-[#1B7A5A]"
                            />
                          ) : (
                            <XCircle
                              size={20}
                              className="text-red-500"
                            />
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-center font-bold text-slate-800">
                        {q.correctAns}
                      </td>
                      <td
                        className={`px-6 py-4 text-center font-bold ${isCorrect ? "text-[#1B7A5A]" : "text-red-500"}`}
                      >
                        {q.userAns}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center justify-end gap-3">
                          <button
                            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-md border transition-colors ${
                              q.logged
                                ? "bg-amber-50 text-amber-700 border-amber-200"
                                : "bg-white text-slate-600 border-slate-200 hover:bg-slate-50"
                            }`}
                          >
                            <Bookmark
                              size={14}
                              className={
                                q.logged ? "fill-amber-700" : ""
                              }
                            />
                            {q.logged ? "Logged" : "Log"}
                          </button>
                          <button className="flex items-center gap-1.5 px-4 py-1.5 bg-[#0F4D38] hover:bg-[#0F4D38]/90 text-white text-xs font-bold rounded-md transition-colors shadow-sm">
                            <Eye size={14} /> Review
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Table Footer / Pagination */}
          <div className="px-6 py-4 border-t border-slate-200 flex items-center justify-between text-sm text-slate-500">
            <span className="font-medium">
              Showing 1 to 7 of 54 entries
            </span>
            <div className="flex items-center gap-1">
              <button className="p-1 rounded text-slate-400 hover:text-slate-800 hover:bg-slate-100 disabled:opacity-50">
                <ChevronLeft size={18} />
              </button>
              <button className="w-7 h-7 flex items-center justify-center rounded bg-[#1B7A5A] text-white font-bold text-xs">
                1
              </button>
              <button className="w-7 h-7 flex items-center justify-center rounded text-slate-600 hover:bg-slate-100 font-bold text-xs">
                2
              </button>
              <button className="w-7 h-7 flex items-center justify-center rounded text-slate-600 hover:bg-slate-100 font-bold text-xs">
                3
              </button>
              <span className="px-1 text-slate-400">...</span>
              <button className="p-1 rounded text-slate-600 hover:text-slate-800 hover:bg-slate-100">
                <ChevronRight size={18} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}