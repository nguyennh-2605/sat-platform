import React from "react";
import {
  FileText,
  Calendar,
  User,
  Info,
  CloudUpload,
  RefreshCcw,
  Trash2,
  Send,
  List,
  Clock,
  CheckCircle2,
  ArrowLeft,
} from "lucide-react";

interface AssignmentStudentViewProps {
  onBack: () => void;
}

export default function AssignmentStudentView({
  onBack,
}: AssignmentStudentViewProps) {
  return (
    <div className="w-full max-w-[1200px] mx-auto font-sans animate-in fade-in duration-300">
      {/* ── NÚT BACK ── */}
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-sm font-bold text-slate-600 hover:text-slate-800 mb-6 transition-colors"
      >
        <ArrowLeft size={16} /> Back
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* ── CỘT TRÁI (8/12): Nội dung bài tập & Bài test yêu cầu ── */}
        <div className="lg:col-span-8 flex flex-col gap-8">
          {/* Assignment Brief Card */}
          <div className="bg-white border border-slate-200 rounded-lg shadow-sm p-6">
            <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2 pb-4 border-b border-slate-300 mb-4">
              <FileText className="text-[#1B7A5A]" size={24} />
              Assignment Brief
            </h2>

            <div className="text-slate-700 leading-relaxed space-y-4 text-[15px]">
              <p>
                This final practice module synthesizes your
                learning from the past three weeks. You are
                required to complete all assigned reading
                passages, focusing specifically on identifying
                the author's primary rhetorical strategies.
              </p>

              <p className="font-semibold text-slate-800">
                Instructions:
              </p>

              <ul className="list-disc pl-5 space-y-2 text-slate-700">
                <li>
                  Complete the 'Ethos, Pathos, Logos' mastery
                  test with a minimum score of 85%.
                </li>
                <li>
                  Work through the 'Identifying Fallacies'
                  Q-Set. Pay special attention to ad hominem and
                  straw man examples.
                </li>
                <li>
                  Draft a 500-word synthesis essay analyzing the
                  provided dual passages. Ensure your thesis
                  clearly addresses the rhetorical differences.
                </li>
              </ul>

              <p>
                Upload your synthesis essay draft in PDF format
                to the submission area on the right before the
                deadline.
              </p>
            </div>
          </div>

          {/* Required Tests Section */}
          <div>
            <h2 className="text-lg font-bold text-slate-800 mb-4">
              Required Tests
            </h2>

            <div className="flex flex-col gap-4">
              {/* Test 1 (In Progress) - Đã bỏ Logo */}
              <div className="bg-white border border-slate-200 rounded-lg shadow-sm p-5 flex items-center justify-between gap-5">
                <div className="flex-1">
                  <h3 className="text-base font-bold text-slate-800 mb-1">
                    Ethos, Pathos, Logos Mastery
                  </h3>
                  <div className="flex items-center gap-4 text-xs font-medium text-slate-500 mb-3">
                    <span className="flex items-center gap-1.5">
                      <List size={14} /> 20 Questions
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Clock size={14} /> 30 Mins Est.
                    </span>
                  </div>
                  {/* Progress Bar */}
                  <div className="flex items-center gap-3">
                    <div className="flex-1 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className="bg-[#1B7A5A] h-full rounded-full"
                        style={{ width: "45%" }}
                      ></div>
                    </div>
                    <span className="text-xs font-bold text-[#1B7A5A]">
                      45%
                    </span>
                  </div>
                </div>

                <div className="shrink-0">
                  <button className="px-5 py-2 rounded-md border border-[#1B7A5A] text-[#1B7A5A] font-semibold text-sm hover:bg-[#eef2ed] transition-colors">
                    Continue
                  </button>
                </div>
              </div>

              {/* Test 2 (Not Started) - Đã bỏ Logo */}
              <div className="bg-white border border-slate-200 rounded-lg shadow-sm p-5 flex items-center justify-between gap-5">
                <div className="flex-1">
                  <h3 className="text-base font-bold text-slate-800 mb-1">
                    Identifying Fallacies Q-Set
                  </h3>
                  <div className="flex items-center gap-4 text-xs font-medium text-slate-500 mb-3">
                    <span className="flex items-center gap-1.5">
                      <List size={14} /> 15 Questions
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Clock size={14} /> 25 Mins Est.
                    </span>
                  </div>
                  {/* Progress Bar */}
                  <div className="flex items-center gap-3">
                    <div className="flex-1 h-1.5 bg-slate-100 rounded-full overflow-hidden"></div>
                    <span className="text-xs font-bold text-slate-500">
                      0%
                    </span>
                  </div>
                </div>

                <div className="shrink-0">
                  <button className="px-7 py-2 rounded-md bg-[#0F4D38] text-white font-semibold text-sm hover:bg-[#0F4D38]/90 transition-colors shadow-sm">
                    Start
                  </button>
                </div>
              </div>

              {/* Load More Button */}
              <button className="w-full py-2.5 mt-2 rounded-lg border border-slate-200 text-slate-600 font-semibold text-sm hover:bg-slate-50 transition-colors">
                Load More Tests
              </button>
            </div>
          </div>
        </div>

        {/* ── CỘT PHẢI (4/12): Thông tin chi tiết & Nộp bài ── */}
        <div className="lg:col-span-4 flex flex-col gap-6">
          {/* Assignment Details Card */}
          <div className="bg-white border border-slate-200 rounded-lg shadow-sm p-6">
            <h3 className="text-lg font-bold text-slate-800 mb-5">
              Assignment Details
            </h3>

            <div className="flex flex-col gap-4">
              <div className="flex items-center justify-between py-2 border-b border-slate-300">
                <div className="flex items-center gap-2 text-slate-600 text-sm">
                  <Calendar size={16} /> Due
                </div>
                <div className="font-semibold text-slate-800 text-sm">
                  Oct 24, 11:59 PM
                </div>
              </div>

              <div className="flex items-center justify-between py-2 border-b border-slate-300">
                <div className="flex items-center gap-2 text-slate-600 text-sm">
                  <User size={16} /> Teacher
                </div>
                <div className="font-semibold text-slate-800 text-sm">
                  Dr. Aris
                </div>
              </div>

              <div className="flex items-center justify-between py-2">
                <div className="flex items-center gap-2 text-slate-600 text-sm">
                  <Info size={16} /> Status
                </div>
                <div className="px-3 py-1 bg-slate-100 text-slate-600 text-xs font-semibold rounded-md border border-slate-200">
                  Not Submitted
                </div>
              </div>
            </div>
          </div>

          {/* Submission Section (Gộp nút Submit vào trong) */}
          <div>
            <h3 className="text-lg font-bold text-slate-800 mb-3">
              Submission
            </h3>

            <div className="bg-white border border-slate-200 rounded-lg shadow-sm p-5 flex flex-col gap-5">
              {/* Drag & Drop Area */}
              <div className="border-2 border-dashed border-slate-300 rounded-lg p-6 flex flex-col items-center justify-center text-center bg-slate-50/50 hover:bg-slate-50 transition-colors cursor-pointer">
                <div className="w-12 h-12 bg-slate-200 text-slate-600 rounded-full flex items-center justify-center mb-3">
                  <CloudUpload size={24} />
                </div>
                <p className="text-sm font-semibold text-slate-800 mb-1">
                  Drag and drop or click to upload
                </p>
                <p className="text-xs text-slate-500 mb-4">
                  PDF, DOCX up to 10MB
                </p>
                <button className="px-4 py-2 text-sm font-semibold text-[#1B7A5A] border border-[#1B7A5A] rounded-md bg-white hover:bg-[#eef2ed] transition-colors">
                  Upload File
                </button>
              </div>

              {/* Uploaded File Item */}
              <div className="bg-[#f4f7f5] border border-[#dce5df] rounded-md p-3 flex items-center gap-3">
                <div className="bg-red-50 p-2 rounded border border-red-100 shrink-0">
                  <FileText
                    className="text-red-600"
                    size={20}
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-slate-800 truncate">
                    Synthesis_E...
                  </p>
                  <div className="flex items-center gap-2 text-xs mt-0.5">
                    <span className="text-slate-500">
                      1.2 MB
                    </span>
                    <span className="w-1 h-1 rounded-full bg-slate-300"></span>
                    <span className="flex items-center gap-1 text-[#1B7A5A] font-semibold">
                      <CheckCircle2 size={12} /> Ready to submit
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  <button
                    className="p-1.5 text-slate-500 hover:text-slate-800 transition-colors"
                    title="Replace file"
                  >
                    <RefreshCcw size={16} />
                  </button>
                  <button
                    className="p-1.5 text-slate-500 hover:text-red-600 transition-colors"
                    title="Delete file"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>

              {/* Nút Submit nằm gọn bên trong Box */}
              <button className="w-full flex items-center justify-center gap-2 py-3 bg-[#0F4D38] text-white rounded-md font-bold hover:bg-[#0F4D38]/90 transition-colors shadow-sm mt-2">
                <Send size={18} /> Submit Assignment
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}