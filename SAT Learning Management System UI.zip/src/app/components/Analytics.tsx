import * as React from "react";
import { useState } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import {
  TrendingUp,
  Trophy,
  BookOpen,
  CheckCircle2,
  AlertCircle,
  Bookmark,
  PenTool,
  ArrowRight,
  Calendar,
} from "lucide-react";
import { GlobalHeader } from "./GlobalHeader";
import TestResultDetails from "./TestResultDetails";

/* ── Score history (raw → converted to %) ─────────────── */
const scoreHistory = [
  {
    date: "Jan 15",
    rw: Math.round((540 / 800) * 100),
    math: Math.round((540 / 800) * 100),
  },
  {
    date: "Feb 3",
    rw: Math.round((570 / 800) * 100),
    math: Math.round((570 / 800) * 100),
  },
  {
    date: "Feb 22",
    rw: Math.round((590 / 800) * 100),
    math: Math.round((600 / 800) * 100),
  },
  {
    date: "Mar 9",
    rw: Math.round((615 / 800) * 100),
    math: Math.round((615 / 800) * 100),
  },
  {
    date: "Mar 23",
    rw: Math.round((625 / 800) * 100),
    math: Math.round((635 / 800) * 100),
  },
  {
    date: "Apr 5",
    rw: Math.round((640 / 800) * 100),
    math: Math.round((640 / 800) * 100),
  },
  {
    date: "Apr 26",
    rw: Math.round((660 / 800) * 100),
    math: Math.round((680 / 800) * 100),
  },
];

/* ── 8-section performance data ──────────────────────── */
const rwSections = [
  { name: "Information and Ideas", pct: 82 },
  { name: "Craft and Structure", pct: 74 },
  { name: "Expression of Ideas", pct: 79 },
  { name: "Standard English Conventions", pct: 76 },
];

const mathSections = [
  { name: "Algebra", pct: 85 },
  { name: "Advanced Math", pct: 68 },
  { name: "Problem Solving & Data Analysis", pct: 78 },
  { name: "Geometry & Trigonometry", pct: 72 },
];

/* ── Recent activity (Table Data) ─────────────────────── */
interface ActivityItem {
  id: number;
  testName: string;
  status: "Completed" | "In Progress";
  date: string;
}

const recentActivity: ActivityItem[] = [
  {
    id: 1,
    testName: "SAT Full Length Practice Test #8",
    status: "Completed",
    date: "Oct 24, 2026",
  },
  {
    id: 2,
    testName: "Math: Advanced Algebra Sprint",
    status: "In Progress",
    date: "Oct 22, 2026",
  },
  {
    id: 3,
    testName: "RW: Expression of Ideas Mini-Test",
    status: "Completed",
    date: "Oct 20, 2026",
  },
  {
    id: 4,
    testName: "SAT Full Length Practice Test #7",
    status: "Completed",
    date: "Oct 15, 2026",
  },
];

/* ── Heatmap mock data ────────────────────────────────── */
// Tạo ngẫu nhiên cường độ học (0 đến 4) cho 84 ngày (12 tuần)
const heatmapData = Array.from({ length: 84 }).map(() =>
  Math.floor(Math.random() * 5),
);

function getHeatmapColor(value: number) {
  if (value === 0) return "#f1f5f9"; // Không học
  if (value === 1) return "#c2ddd4"; // Nhẹ
  if (value === 2) return "#86c1aa"; // Vừa
  if (value === 3) return "#4a9c7e"; // Khá
  return "#1B7A5A"; // Rất nhiều
}

/* ── Custom tooltip ───────────────────────────────────── */
function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div
      className="bg-card border border-border rounded-lg px-3 py-2 shadow-md text-xs"
      style={{
        color: "var(--foreground)",
        backgroundColor: "#fff",
      }}
    >
      <p className="text-muted-foreground mb-1">{label}</p>
      {payload.map((p: any) => (
        <p
          key={p.dataKey}
          style={{ color: p.color, fontWeight: 600 }}
        >
          {p.name}: {p.value}%
        </p>
      ))}
    </div>
  );
}

export function Analytics() {
  const [selectedTestId, setSelectedTestId] = useState<
    number | null
  >(null);

  if (selectedTestId !== null) {
    return (
      <TestResultDetails
        onBack={() => setSelectedTestId(null)}
      />
    );
  }

  return (
    <div className="flex flex-col h-full bg-background overflow-hidden">
      <GlobalHeader
        title="Analytics"
        subtitle="Nguyễn Linh · SAT Intensive 2026"
      />

      <div className="flex-1 overflow-y-auto p-8 pt-6">
        <div className="max-w-[1200px] mx-auto">
          {/* ── 3 KPI cards ─────────────────────────────── */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            {/* Accuracy */}
            <div className="bg-white border border-border rounded-xl p-5 flex items-center gap-4 shadow-sm">
              <div
                className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0"
                style={{ background: "#E8F5EF" }}
              >
                <CheckCircle2
                  size={22}
                  style={{ color: "#1B7A5A" }}
                />
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-0.5 font-medium">
                  Overall Accuracy
                </p>
                <div className="flex items-baseline gap-1.5">
                  <span
                    className="text-3xl"
                    style={{
                      fontWeight: 800,
                      fontFamily: "monospace",
                      color: "#1B7A5A",
                    }}
                  >
                    82.5%
                  </span>
                </div>
              </div>
            </div>

            {/* Saved Questions */}
            <div className="bg-white border border-border rounded-xl p-5 flex items-center gap-4 shadow-sm">
              <div
                className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0"
                style={{ background: "#FEF9E7" }}
              >
                <Bookmark
                  size={22}
                  style={{ color: "#E8C040" }}
                />
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-0.5 font-medium">
                  Saved Questions
                </p>
                <div className="flex items-baseline gap-1.5">
                  <span
                    className="text-3xl"
                    style={{
                      fontWeight: 800,
                      fontFamily: "monospace",
                      color: "#92640a",
                    }}
                  >
                    142
                  </span>
                  <span className="text-sm text-muted-foreground">
                    questions
                  </span>
                </div>
              </div>
            </div>

            {/* Questions Attempted */}
            <div className="bg-white border border-border rounded-xl p-5 flex items-center gap-4 shadow-sm">
              <div className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0 bg-slate-100">
                <PenTool size={22} className="text-slate-600" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-0.5 font-medium">
                  Questions Attempted
                </p>
                <div className="flex items-baseline gap-1.5">
                  <span
                    className="text-3xl font-extrabold text-slate-800"
                    style={{ fontFamily: "monospace" }}
                  >
                    1,250
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* ── Score progress line chart ─────────────────── */}
          <div className="bg-white border border-border rounded-xl p-5 mb-6 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-bold text-slate-800">
                  Score Progress
                </h3>
                <p className="text-xs text-muted-foreground">
                  Accuracy percentage across 7 practice tests
                </p>
              </div>
              <div className="flex items-center gap-4 text-xs font-medium text-slate-600">
                <span className="flex items-center gap-1.5">
                  <span
                    className="w-3 h-0.5 rounded-full inline-block"
                    style={{ background: "#1B7A5A" }}
                  />
                  RW
                </span>
                <span className="flex items-center gap-1.5">
                  <span
                    className="w-3 h-0.5 rounded-full inline-block"
                    style={{ background: "#E8C040" }}
                  />
                  Math
                </span>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={220}>
              <LineChart
                data={scoreHistory}
                margin={{
                  top: 4,
                  right: 12,
                  bottom: 0,
                  left: -10,
                }}
              >
                <CartesianGrid
                  strokeDasharray="3 3"
                  stroke="#e2e8f0"
                />
                <XAxis
                  dataKey="date"
                  tick={{ fontSize: 11, fill: "#64748b" }}
                  axisLine={{ stroke: "#cbd5e1" }}
                  tickLine={false}
                />
                <YAxis
                  domain={[55, 100]}
                  tickFormatter={(v) => `${v}%`}
                  tick={{ fontSize: 11, fill: "#64748b" }}
                  axisLine={{ stroke: "#cbd5e1" }}
                  tickLine={false}
                />
                <Tooltip content={<CustomTooltip />} />
                {/* 2 Đường hiển thị song song trong cùng 1 chart */}
                <Line
                  type="monotone"
                  dataKey="rw"
                  name="RW"
                  stroke="#1B7A5A"
                  strokeWidth={2.5}
                  dot={{
                    r: 4,
                    fill: "#1B7A5A",
                    strokeWidth: 0,
                  }}
                  activeDot={{ r: 6 }}
                />
                <Line
                  type="monotone"
                  dataKey="math"
                  name="Math"
                  stroke="#E8C040"
                  strokeWidth={2.5}
                  dot={{
                    r: 4,
                    fill: "#E8C040",
                    strokeWidth: 0,
                  }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* ── Heatmap ───────────────────────────────────── */}
          <div className="bg-white border border-border rounded-xl p-5 mb-6 shadow-sm">
            <div className="flex flex-col md:flex-row md:items-center justify-between mb-4 gap-4">
              <div>
                <h3 className="font-bold text-slate-800 flex items-center gap-2">
                  <Calendar
                    size={18}
                    className="text-[#1B7A5A]"
                  />
                  Activity Heatmap
                </h3>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Your study streaks over the last 12 weeks
                </p>
              </div>
              <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium">
                <span>Less</span>
                <div className="flex gap-1">
                  {[0, 1, 2, 3, 4].map((level) => (
                    <div
                      key={level}
                      className="w-3 h-3 rounded-[2px]"
                      style={{
                        backgroundColor: getHeatmapColor(level),
                      }}
                    ></div>
                  ))}
                </div>
                <span>More</span>
              </div>
            </div>

            {/* Vẽ lưới heatmap đơn giản */}
            <div className="flex flex-wrap gap-1.5">
              {heatmapData.map((val, idx) => (
                <div
                  key={idx}
                  className="w-4 h-4 rounded-[3px] transition-transform hover:scale-110 cursor-pointer"
                  style={{
                    backgroundColor: getHeatmapColor(val),
                  }}
                  title={`${val} activities on this day`}
                ></div>
              ))}
            </div>
          </div>

          {/* ── Section Performance ───────────────────────── */}
          <div className="bg-white border border-border rounded-xl p-6 mb-6 shadow-sm">
            <h3 className="font-bold text-slate-800 mb-5">
              Section Performance Breakdown
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* RW group */}
              <div>
                <div
                  className="flex items-center gap-2 mb-4 text-xs px-3 py-1.5 rounded-md w-fit"
                  style={{
                    background: "#E8F5EF",
                    color: "#1B7A5A",
                    fontWeight: 700,
                  }}
                >
                  Reading & Writing
                </div>
                <div className="flex flex-col gap-4">
                  {rwSections.map((s) => (
                    <SectionBar
                      key={s.name}
                      name={s.name}
                      pct={s.pct}
                      color="#1B7A5A"
                    />
                  ))}
                </div>
              </div>

              {/* Math group */}
              <div>
                <div
                  className="flex items-center gap-2 mb-4 text-xs px-3 py-1.5 rounded-md w-fit"
                  style={{
                    background: "#FEF9E7",
                    color: "#92640a",
                    fontWeight: 700,
                  }}
                >
                  Math
                </div>
                <div className="flex flex-col gap-4">
                  {mathSections.map((s) => (
                    <SectionBar
                      key={s.name}
                      name={s.name}
                      pct={s.pct}
                      color="#E8C040"
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* ── Recent Activity Table ─────────────────────── */}
          <div className="bg-white border border-border rounded-xl shadow-sm overflow-hidden mb-8">
            <div className="p-5 border-b border-border">
              <h3 className="font-bold text-slate-800">
                Recent Activity
              </h3>
              <p className="text-xs text-muted-foreground">
                Detailed history of your latest attempts
              </p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="text-xs text-slate-500 bg-slate-50 border-b border-border uppercase font-semibold">
                  <tr>
                    <th className="px-5 py-3">Test Name</th>
                    <th className="px-5 py-3">Status</th>
                    <th className="px-5 py-3">Date</th>
                    <th className="px-5 py-3 text-right">
                      Action
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {recentActivity.map((item) => (
                    <tr
                      key={item.id}
                      className="hover:bg-slate-50/50 transition-colors"
                    >
                      <td className="px-5 py-4 font-medium text-slate-800">
                        {item.testName}
                      </td>
                      <td className="px-5 py-4">
                        <span
                          className={`inline-flex items-center px-2 py-1 rounded text-[11px] font-bold ${
                            item.status === "Completed"
                              ? "bg-emerald-50 text-emerald-700 border border-emerald-200"
                              : "bg-amber-50 text-amber-700 border border-amber-200"
                          }`}
                        >
                          {item.status}
                        </span>
                      </td>
                      <td className="px-5 py-4 text-slate-600 text-xs font-medium">
                        {item.date}
                      </td>
                      <td className="px-5 py-4 text-right">
                        <button
                          onClick={() =>
                            setSelectedTestId(item.id)
                          }
                          className="inline-flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-bold text-[#1B7A5A] bg-white border border-[#1B7A5A] rounded hover:bg-[#E8F5EF] transition-colors"
                        >
                          View Details <ArrowRight size={12} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ── Section Bar ──────────────────────────────────────── */
function SectionBar({
  name,
  pct,
  color,
}: {
  name: string;
  pct: number;
  color: string;
}) {
  return (
    <div className="flex items-center gap-4">
      <p
        className="text-sm text-slate-700 shrink-0 w-52 truncate"
        style={{ fontWeight: 600 }}
        title={name}
      >
        {name}
      </p>
      <div className="flex-1 h-2.5 bg-slate-100 rounded-full overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-500"
          style={{ width: `${pct}%`, background: color }}
        />
      </div>
      <span
        className="text-sm shrink-0 w-10 text-right"
        style={{
          fontFamily: "monospace",
          fontWeight: 700,
          color,
        }}
      >
        {pct}%
      </span>
    </div>
  );
}