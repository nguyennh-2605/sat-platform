import { useState, useEffect } from "react";
import { Sidebar, type Module } from "./components/Sidebar";
import { TestBank } from "./components/TestBank";
import { Classroom } from "./components/Classroom";
import { ErrorLog } from "./components/ErrorLog";
import { Analytics } from "./components/Analytics";
import { AuthProvider, useAuth } from "./AuthContext";
import { Login } from "./components/Login";

/* MARKER-MAKE-KIT-INVOKED */
/* MARKER-MAKE-KIT-DISCOVERY-READ */

function MainApp() {
  const { role } = useAuth();
  const [module, setModule] = useState<Module>("analytics");

  // If teacher and module is errorlog, switch back to analytics
  useEffect(() => {
    if (role === "teacher" && module === "errorlog") {
      setModule("analytics");
    }
  }, [role, module]);

  if (!role) {
    return <Login />;
  }

  return (
    <div className="flex h-screen w-full overflow-hidden bg-background">
      <Sidebar active={module} onChange={setModule} />
      <main className="flex-1 overflow-hidden">
        {module === "testbank" && <TestBank />}
        {module === "classroom" && <Classroom />}
        {module === "errorlog" && role !== "teacher" && <ErrorLog />}
        {module === "analytics" && <Analytics />}
      </main>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
